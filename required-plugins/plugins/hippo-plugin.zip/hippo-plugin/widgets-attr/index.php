<?php

    !defined(ABSPATH) or die('Keep silent!');

    define('EM_WIDGET_ATTR_DIR', dirname(__FILE__));
    define('EM_WIDGET_ATTR_RELATIVE_PATH', dirname(plugin_basename(__FILE__)));
    define('EM_WIDGET_ATTR_URL', plugins_url(basename(dirname(__FILE__)), dirname(__FILE__)));


    class Hippo_Widget_Attrs
    {

        public function __construct()
        {
            add_action('init', array($this, 'setup'));
        }

        public function setup()
        {
            add_action('in_widget_form', array($this, 'form'), 10, 3);
            add_filter('widget_update_callback', array($this, 'save_update'), 10, 2);
            add_filter('dynamic_sidebar_params', array($this, 'display'));
        }

        public function form($widget, $return, $instance)
        {


            $value = isset($instance[ 'hippo_custom_class' ]) ? $instance[ 'hippo_custom_class' ] : '';

            ob_start();
            ?>
            <p>
                <label
                    for="<?php echo $widget->get_field_id('hippo_custom_class') ?>"><?php _e('Bootstrap Grid Class:', HIPPO_PLUGIIN_TEXTDOMAIN) ?>
                    <input class="widefat" value="<?php echo $value ?>"
                           id="<?php echo $widget->get_field_id('hippo_custom_class') ?>"
                           name="<?php echo $widget->get_field_name('hippo_custom_class') ?>">
                </label>
            </p>
            <?php
            echo ob_get_clean();
        }

        public function save_update($instance, $new_instance)
        {
            $instance[ 'hippo_custom_class' ] = $new_instance[ 'hippo_custom_class' ];
            return $instance;
        }

        public function display($params)
        {

            global $wp_registered_widgets;
            $widget_id  = $params[ 0 ][ 'widget_id' ];
            $widget_obj = $wp_registered_widgets[ $widget_id ];
            $widget_opt = get_option($widget_obj[ 'callback' ][ 0 ]->option_name);
            $widget_num = $widget_obj[ 'params' ][ 0 ][ 'number' ];
            $value      = isset($widget_opt[ $widget_num ][ 'hippo_custom_class' ]) ? $widget_opt[ $widget_num ][ 'hippo_custom_class' ] : '';


            if (preg_match('/class="/', $params[ 0 ][ 'before_widget' ])) {

                if( $value ) $params[ 0 ][ 'before_widget' ] = str_ireplace('col-md-3', '', $params[ 0 ][ 'before_widget' ]);
                $params[ 0 ][ 'before_widget' ] = preg_replace('/class="/', "class=\"{$value} ", $params[ 0 ][ 'before_widget' ], 1);
            } else {
                $params[ 0 ][ 'before_widget' ] = preg_replace('/(\<[a-zA-Z]+)(.*?)(\>)/', "$1 $2 class=\"{$value}\" $3", $params[ 0 ][ 'before_widget' ], 1);
            }

            return $params;

        }

    }

    $Hippo_Widget_Attrs = new Hippo_Widget_Attrs();