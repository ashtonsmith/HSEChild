<?php

    defined('ABSPATH') or die('Keep Silent');

    global $pagenow;

    if ($pagenow == 'nav-menus.php') {

        //die(__FILE__);

        require_once ABSPATH . 'wp-admin/includes/nav-menu.php';

        class Hippo_Walker_Nav_Menu_Edit extends Walker_Nav_Menu_Edit
        {


            /***

            function start_el(&$output, $item, $depth=0, $args=array(), $id=0)
            {
                $item_output = '';
                parent::start_el($item_output, $item, $depth, $args, $id);
                // Inject $new_fields before: <div class="menu-item-actions description-wide submitbox">
                if ($new_fields = em_MenuMeta_Engine::getInstance()->generate_field($item, $depth, $args)) {
                    $item_output = preg_replace('/(?=<div[^>]+class="[^"]*submitbox)/', $new_fields, $item_output);
                }
                $output .= $item_output;
            }

*/



            function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        $item_output = '';
        parent::start_el( $item_output, $item, $depth, $args, $id );
        $output .= preg_replace(
            // NOTE: Check this regex from time to time!
            '/(?=<p[^>]+class="[^"]*field-move)/',
            em_MenuMeta_Engine::getInstance()->generate_field( $item, $depth, $args ),
            $item_output
        );
    }


        }
    }