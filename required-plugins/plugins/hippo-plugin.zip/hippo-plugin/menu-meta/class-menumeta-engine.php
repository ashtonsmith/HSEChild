<?php

    defined('ABSPATH') or die('Keep Silent');


    class em_MenuMeta_Engine
    {

        private $_meta_key_prefix = 'hippo_menu_meta_';
        private $_fields = array();
        private static $instance = NULL;


        public static function getInstance()
        {
            if (is_null(self::$instance)) {
                self::$instance = new em_MenuMeta_Engine();
            }
            return self::$instance;
        }

        public function __construct()
        {
            add_action('init', array($this, 'setup'));
            add_action('admin_enqueue_scripts', array($this, 'on_admin_script_load'));
        }

        public function on_admin_script_load()
        {
            wp_enqueue_style('em-menu-meta-style', EM_MENU_META_URL . '/css/style.css');
        }


        public function setup()
        {

            $fields = apply_filters('hippo_nav_menu_item_meta', self::getInstance()->_fields);

            if (empty($fields))
                return;

            foreach ($fields as $field_key => $field) {
                self::getInstance()->_fields[ $field_key ] = $fields[ $field_key ];
            }

            require_once dirname(__FILE__) . '/class-navmenuedit-walker.php';

            add_filter('wp_edit_nav_menu_walker', function () {
                return 'Hippo_Walker_Nav_Menu_Edit';
            });

            add_action('save_post', array(self::getInstance(), 'save_menu_meta'), 10, 2);
        }

        public function save_menu_meta($post_id, $post)
        {

            if ($post->post_type !== 'nav_menu_item') {
                return;
            }

            foreach (self::getInstance()->_fields as $field_name => $field) {

                $form_field_name = 'menu-item-' . $field_name;

                if (isset($_POST[ $form_field_name ][ $post_id ])) {

                    $key   = $this->_meta_key_prefix . $field_name;
                    $value = stripslashes($_POST[ $form_field_name ][ $post_id ]);
                    update_post_meta($post_id, $key, $value);
                }
            }
        }


        public static function get_menu_meta($id, $name)
        {
            return get_post_meta($id, self::getInstance()->_meta_key_prefix . $name, TRUE);
        }


        public function generate_field($item, $depth, $args)
        {

            $fields = '';
            foreach (self::getInstance()->_fields as $key_name => $field) {


                $field[ 'name' ] = $key_name;

                $field[ 'default' ] = (isset($field[ 'default' ])) ? $field[ 'default' ] : NULL;

                $value            = self::getInstance()->get_menu_meta($item->ID, $field[ 'name' ], TRUE);
                $field[ 'value' ] = (empty($value)) ? $field[ 'default' ] : $value;

                $field[ 'id' ] = $item->ID;

                $field[ 'size' ] = (isset($field[ 'size' ])) ? $field[ 'size' ] : 'wide';

                $field[ 'size' ] = ($field[ 'size' ] == 'half') ? 'thin' : $field[ 'size' ];


                $fields .= self::getInstance()->attribute($field);

            }
            return $fields;
        }


        public function attribute($field)
        {

            ob_start();

            ?>

            <p class="additional-menu-field-<?php echo $field[ 'name' ] ?> description description-<?php echo $field[ 'size' ] ?>">

                <?php
                    switch ($field[ 'type' ]) {

                        case 'checkbox':
                        case 'radio':
                            ?>
                            <label
                                for="edit-menu-item-<?php echo $field[ 'name' ] ?>-<?php echo $field[ 'id' ] ?>">
                                <input type="<?php echo $field[ 'type' ] ?>"
                                       id="edit-menu-item-<?php echo $field[ 'name' ] ?>-<?php echo $field[ 'id' ] ?>"
                                       class="widefat code edit-menu-item-<?php echo $field[ 'name' ] ?>"
                                       name="menu-item-<?php echo $field[ 'name' ] ?>[<?php echo $field[ 'id' ] ?>]"
                                       value="<?php echo esc_attr($field[ 'value' ]) ?>">
                                <?php echo $field[ 'label' ] ?></label>
                            <?php

                            break;

                        case 'textarea':
                            ?>
                            <label
                                for="edit-menu-item-<?php echo $field[ 'name' ] ?>-<?php echo $field[ 'id' ] ?>">
                                <?php echo $field[ 'label' ] ?><br>
                                <textarea
                                    id="edit-menu-item-<?php echo $field[ 'name' ] ?>-<?php echo $field[ 'id' ] ?>"
                                    class="widefat code edit-menu-item-<?php echo $field[ 'name' ] ?>"
                                    name="menu-item-<?php echo $field[ 'name' ] ?>[<?php echo $field[ 'id' ] ?>]"><?php echo $field[ 'value' ] ?></textarea>
                            </label>
                            <?php
                            break;

                        case 'select':
                            $field[ 'options' ] = isset($field[ 'options' ]) ? $field[ 'options' ] : array();
                            ?>
                            <label
                                for="edit-menu-item-<?php echo $field[ 'name' ] ?>-<?php echo $field[ 'id' ] ?>">
                                <?php echo $field[ 'label' ] ?><br>
                                <select
                                    id="edit-menu-item-<?php echo $field[ 'name' ] ?>-<?php echo $field[ 'id' ] ?>"
                                    class="widefat code edit-menu-item-<?php echo $field[ 'name' ] ?>"
                                    name="menu-item-<?php echo $field[ 'name' ] ?>[<?php echo $field[ 'id' ] ?>]">

                                    <?php foreach ($field[ 'options' ] as $key => $value) { ?>
                                        <option
                                            value="<?php echo $key ?>" <?php selected($key, $field[ 'value' ]) ?>><?php echo $value ?></option>
                                    <?php } ?>

                                </select>
                            </label>
                            <?php
                            break;

                        case 'text':
                        default:
                            ?>
                                <label
                                    for="edit-menu-item-<?php echo $field[ 'name' ] ?>-<?php echo $field[ 'id' ] ?>">
                                    <?php echo $field[ 'label' ] ?><br>
                                    <input
                                        type="<?php echo $field[ 'type' ] ?>"
                                        id="edit-menu-item-<?php echo $field[ 'name' ] ?>-<?php echo $field[ 'id' ] ?>"
                                        class="widefat code edit-menu-item-<?php echo $field[ 'name' ] ?>"
                                        name="menu-item-<?php echo $field[ 'name' ] ?>[<?php echo $field[ 'id' ] ?>]"
                                        value="<?php echo esc_attr($field[ 'value' ]) ?>">
                                </label>
                            <?php
                            break;
                    }
                ?>
            </p>

            <?php
            return ob_get_clean();
        }
    }

    $_GLOBALS[ 'hippo_menu_meta' ] = em_MenuMeta_Engine::getInstance();

    if (!function_exists('hippo_get_menu_meta')) {
        function hippo_get_menu_meta($id, $name)
        {
            return em_MenuMeta_Engine::getInstance()->get_menu_meta($id, $name);
        }
    }


/**
 * Adding Meta Field
 *
 *
 *    add_filter('hippo_nav_menu_item_meta', function ($fields) {
 *
 * $fields[ 'color' ] = array(
 * 'type'            => 'color',
 * 'label'           => __('Color', HIPPO_PLUGIIN_TEXTDOMAIN),
 * 'container_class' => 'link-color',
 * );
 *
 * return $fields;
 * });
 */

/**
 * On Nav Walker
 *
 *
 * echo hippo_get_menu_meta($item->ID,'color');
 *
 */





