/*------------------------------------*\

 Name: hippo.js
 Author: Theme Hippo
 Author URI: http://www.themehippo.com
 Version: 0.1

\*------------------------------------*/

jQuery(function ($) {


    function call_select2() {

        $(".select2").select2();

        function icon_format(state) {
            var originalOption = state.element;
            return "<i class='" + state.id + "'></i> " + state.text;
        }


        $(".select2-icon").select2({
            formatResult   : icon_format,
            formatSelection: icon_format,
            escapeMarkup   : function (m) {
                return m;
            }
        });

    }


    $(".meta_box_items.icons .meta-icon-meta-box label").on("click", function (e) {
        //e.stopPropagation();
        $(this).closest('.meta-icon-meta-box').find('label').removeClass('selected');
        $(this).addClass('selected');
    });

    var tb_opener = null;
    $('a.meta-icon-selector').on('click', function () {
        tb_opener = this;
        var href = $(this).attr('href');
        tb_show('Icons', href);
        return false;

    });

    $('a.meta-icon-remove').on('click', function () {
        $(this).closest('ul.meta_box_items').find('.preview-icon > i').removeClass();
        $(this).closest('ul.meta_box_items').find('.hidden-textbox').val('');
        $(this).hide();
        return false;
    });

    $('.meta-icon-meta-box i').on('click', function () {
        var iconname = $(this).prev().val();
        $(tb_opener).closest('ul.meta_box_items').find('.preview-icon > i').removeClass().addClass(iconname);
        $(tb_opener).closest('ul.meta_box_items').find('.hidden-textbox').val(iconname);
        $(tb_opener).next().show();
        tb_remove();
        tb_opener = null;

    });
});




