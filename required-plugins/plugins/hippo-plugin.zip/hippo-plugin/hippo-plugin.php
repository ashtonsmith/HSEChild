<?php
    /**
     * Plugin Name: Hippo Theme Plugin
     * Description: Theme Hippo theme plugin
     * Version: 0.1
     * Author: Theme Hippo
     * Author URI: http://www.themehippo.com
     * License: A "GPL2"
     */


    //---------------------------------------------------------------------
    // Defining Constance
    //---------------------------------------------------------------------

    if (!defined('HIPPO_PLUGIIN_TEXTDOMAIN')) {
        define('HIPPO_PLUGIIN_TEXTDOMAIN', 'hippo-plugin');
    }

    if (!defined('HIPPO_THEME_NAME')) {
        define('HIPPO_THEME_NAME', wp_get_theme()->get('Name'));
    }

    if (!defined('HIPPO_THEME_VERSION')) {
        define('HIPPO_THEME_VERSION', wp_get_theme()->get('Version'));
    }

    define('HIPPO_PLUGIN_URL', plugin_dir_url(__FILE__));
    define('HIPPO_PLUGIN_DIR', dirname(__FILE__));
    define('HIPPO_PLUGIN_RELATIVE_PATH', dirname(plugin_basename(__FILE__)));

    //---------------------------------------------------------------------
    // Loading TextDomain
    //---------------------------------------------------------------------

    function hippo_plugin_init()
    {
        load_plugin_textdomain(HIPPO_PLUGIIN_TEXTDOMAIN, FALSE, HIPPO_PLUGIN_RELATIVE_PATH . '/languages/');
    }

    add_action('plugins_loaded', 'hippo_plugin_init');

    //---------------------------------------------------------------------
    // Loading Admin Scripts, Stylesheets
    //---------------------------------------------------------------------

    function hippo_wp_admin_scripts()
    {
        // font awesome
        wp_enqueue_style('fontawesome', HIPPO_PLUGIN_URL . 'css/font-awesome.min.css');

        // select 2
        wp_enqueue_style('select2', HIPPO_PLUGIN_URL . 'css/select2.css');

        // custom css
        wp_enqueue_style('hippo_admin_style', HIPPO_PLUGIN_URL . 'css/hippo.css');

        // select 2
        wp_enqueue_script('select2', HIPPO_PLUGIN_URL . 'js/select2.min.js');

        // custom script
        wp_enqueue_script('hippo_admin_script', HIPPO_PLUGIN_URL . 'js/hippo.js');
    }

    add_action('admin_enqueue_scripts', 'hippo_wp_admin_scripts');


    //---------------------------------------------------------------------
    // Loading FontAwesome Icons array
    //---------------------------------------------------------------------

    require_once "font-awesome-icons/font-awesome-icons.php";

    //---------------------------------------------------------------------
    // Loading Short code generator
    //---------------------------------------------------------------------

    require_once "shortcode/index.php";

    //---------------------------------------------------------------------
    // Loading metabox generator
    //---------------------------------------------------------------------

    require_once "metaboxes/index.php";

    //---------------------------------------------------------------------
    // Loading custom post type generator
    //---------------------------------------------------------------------

    require_once "post-types/index.php";

    //---------------------------------------------------------------------
    // Loading Demo data installer
    //---------------------------------------------------------------------

    require_once "data-import/index.php";

    //---------------------------------------------------------------------
    // Admin Menu Meta
    //---------------------------------------------------------------------

    require_once "menu-meta/index.php";

    //---------------------------------------------------------------------
    // Widget Class Field
    //---------------------------------------------------------------------

    require_once "widgets-attr/index.php";

