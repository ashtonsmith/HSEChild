<?php

function hippo_register_feature_news_shortcode($shortcode)
{
    $register = array(
        'title'       => __('Featured news', EM_SHORTCODES_TEXTDOMAIN),
        'description' => __('Featured news', EM_SHORTCODES_TEXTDOMAIN),
        'attributes'  => array(
                'title'    => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Title Name', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Title Name', EM_SHORTCODES_TEXTDOMAIN),
                    ),

                'limit'       => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Post limit', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Post limit', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '10'
                    ),

                )
            );

    $shortcode->register('feature-news', $register);
}

add_action('hippo_register_shortcode', 'hippo_register_feature_news_shortcode');


function hippo_shortcode_feature_news($atts, $contents = '')
{
    $attributes = shortcode_atts(array(
        'title'    => '',
        'limit'       => 10,

        ), $atts);

    ob_start();


    ?>

        <div class="mag-right-column">
            <h2><?php echo $attributes ['title'] ?></h2>
            

   
        <?php

        // WP_Query arguments

        $args = array(
            'posts_per_page' => $attributes['limit'],
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'post__in'       => get_option( 'sticky_posts' ),
            );

            // The Query
            $query = new WP_Query($args);

            $total_post = $query->post_count;

        // The Loop
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $post     = get_post();
             
             ?>
                        

                <div class="mag-right-item">
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="post-meta clearfix">
                        <ul>
                            <!-- <li><span class="category"><?php echo get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', EM_SHORTCODES_TEXTDOMAIN ) ); ?></span></li> -->
                            <li><span class="author"><i class="fa fa-user"></i><?php the_author_posts_link(); ?></span></li>
                            <li><span class="date"><i class="fa fa-calendar"></i> <?php the_time('j F, Y') ?></span></li>
                        </ul>
                    </div>
                </div>

                <?php

            }
        }

        wp_reset_postdata();
        ?>

			
	</div>


<?php

return ob_get_clean();
}

add_shortcode('feature-news', 'hippo_shortcode_feature_news');