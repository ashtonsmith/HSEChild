<?php



    function hippo_register_faqs_shortcode($shortcode)
    {


        $register_faqs = array(
            'title'       => __('Faq with accordion', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Faq with accordion', EM_SHORTCODES_TEXTDOMAIN),
        );


        $shortcode->register('faqs', $register_faqs);

        $register_faq_link = array(
            'title'       => __('Faq with accordion', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Faq with accordion', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'    => array('faqs'), // use if its a child
            'cloneable'   => TRUE, // use if its a child
            'editor_contents' => TRUE,
            'attributes'  => array(

                'title'        => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put title', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '',
                ),


                'default' => array(
                    'type'        => 'select',
                    'label'       => __('Default Panel', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Set default panel', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''        => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'in' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                ),

                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                ),

                
            )

        );

        $shortcode->register('faq', $register_faq_link);
    }

    add_action('hippo_register_shortcode', 'hippo_register_faqs_shortcode');


    function hippo_shortcode_faqs($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(), $atts);
        ob_start();
        ?>
        <div class="faq-wrapper <?php echo $attributes['shadow_class'] ?>">
            <div class="panel-group" id="accordion">
            
            <?php
                echo do_shortcode($contents);
            ?>
           
            </div>
        </div>
        <?php

        return ob_get_clean();
    }

    add_shortcode('faqs', 'hippo_shortcode_faqs');

    function hippo_shortcode_faq($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'title' => '',
            'default' => '',
            'shadow_class' => '',
        ), $atts);


        $id = rand(2,20);

        ob_start();
        ?>

            <div class="panel panel-default">
                <div class="panel-heading faq-heading">
                    <h2 class="panel-title">
                        
                        <a class="collapse-title faq-title"
                           data-toggle="collapse" data-parent="#accordion" href="#faq<?php echo $id ?>">
                            <?php echo $attributes ['title'] ?>
                        </a>
                        
                    </h2>
                </div>
                <!-- end of panel heading -->

                <div class="panel-collapse collapse <?php echo $attributes ['default'] ?>" id="faq<?php echo $id ?>">
                    <div class="panel-body">
                        <?php
                            echo do_shortcode($contents);
                        ?>
                    </div>
                    <!-- end of panel body -->
                </div>
            </div>


        <?php
        return ob_get_clean();
    }

    add_shortcode('faq', 'hippo_shortcode_faq');









