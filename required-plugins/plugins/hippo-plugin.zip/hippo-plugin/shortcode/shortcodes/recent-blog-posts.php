<?php
    function hippo_register_recent_blog_shortcode($shortcode)
    {
        $register = array(
            'title'       => __('Recent Blog Posts', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Show Recent Blog posts', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(

                'title'        => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'Latest News &amp; Events',
                ),

                'limit'        => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Post limit', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Number of Post', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '10'
                ),

                'word_limit'   => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Word limit', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put number of word', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '15'
                ),

                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                ),


            )
        );

        $shortcode->register('recent-blog-posts', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_recent_blog_shortcode');


    function hippo_shortcode_recent_blog($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'title'      => 'Latest News &amp; Events',
            'limit'      => 10,
            'word_limit' => 15,
            'shadow_class' => '',
        ), $atts);
        ob_start();

        ?>




        <div class="latest-news-box <?php echo $attributes[ 'shadow_class' ] ?>">
            <h2 class="lead-title"><?php echo $attributes[ 'title' ] ?></h2>

            <div class="latest-news-caruosel">
                <div id="latest-news" class="latest-news">
                    <?php

                        // WP_Query arguments


                        $args = array(
                            'posts_per_page' => $attributes[ 'limit' ],
                            'post_type'      => 'post',
                            'post_status'    => 'publish',
                            'post__not_in'   => get_option('sticky_posts'),
                        );

                        // The Query
                        $query = new WP_Query($args);


                        $total_post = $query->post_count;


                        // The Loop
                        if ($query->have_posts()) {
                            while ($query->have_posts()) {
                                $query->the_post();
                                $post = get_post();

                                ?>

                                <div class="item">
                                    <div class="single-latest">
                                        <?php the_post_thumbnail('latest-post', array('class' => 'imgthumb')); ?>
                                        <p class="date-meta"><?php the_time('j F, Y') ?> </p>
                                        <h4><?php the_title(); ?></h4>

                                        <p><?php echo wp_trim_words(get_the_content(), $attributes[ 'word_limit' ]); ?></p>

                                        <div class="readmore"><a
                                                href="<?php the_permalink(); ?>"><?php _e('More ', EM_SHORTCODES_TEXTDOMAIN) ?></a>
                                        </div>
                                    </div>
                                </div>


                            <?php


                            }
                        }

                        wp_reset_postdata();
                    ?>
                </div>

                <div class="customNavigation latest-news-navigation">
                    <a class="next"><i class="fa fa-angle-right"></i></a>
                    <a class="prev"><i class="fa fa-angle-left"></i></a>
                </div>
            </div>
        </div>




        <?php
        return ob_get_clean();
    }

    add_shortcode('recent-blog-posts', 'hippo_shortcode_recent_blog');

