<?php

    function hippo_register_accordion_shortcode($shortcode)
    {
        $register = array(
            'title'       => __('Accordion', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Accordion', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(

                'title'        => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put title', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '',
                ),

                'post'         => array(
                    'type'        => 'post', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Post', EM_SHORTCODES_TEXTDOMAIN),
                    'post_type'   => 'post',
                    'description' => __('Select your post', EM_SHORTCODES_TEXTDOMAIN),
                    'multiple'    => TRUE,
                ),

                'word_limit'   => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Word limit', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put number of word', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '20'
                ),

                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                ),

            )
        );

        $shortcode->register('accordion', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_accordion_shortcode');


    function hippo_shortcode_accordion($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'title'        => '',
            'post'         => '0',
            'word_limit'   => 20,
            'shadow_class' => ''
        ), $atts);

        ob_start();
        ?>
        <div class="accordion-box <?php echo $attributes['shadow_class'] ?>">
            <h2 class="lead-title"><?php echo $attributes[ 'title' ] ?></h2>

            <div class="panel-group testimonial-panel" id="accordion">

                <?php

                    // WP_Query arguments


                    $args = array(
                        'post_type'    => 'post',
                        'post_status'  => 'publish',
                        'post__in'     => explode(',', $attributes[ 'post' ]),
                        'post__not_in' => get_option('sticky_posts'),
                        'has_password' => FALSE,
                    );

                    // The Query
                    $query = new WP_Query($args);


                    $total_post = $query->post_count;


                    // The Loop
                    if ($query->have_posts()) {

                        $increment = 0;

                        while ($query->have_posts()) {
                            $query->the_post();
                            $post = get_post();

                            ?>

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a class="collapse-title <?php echo(($increment > 0) ? 'collapsed' : '') ?>"
                                           data-toggle="collapse" data-parent="#accordion"
                                           href="#accordion<?php the_ID(); ?>">
                                            <?php the_title(); ?>
                                        </a>
                                    </h4>
                                </div>
                                <!-- end of panel heading -->

                                <div class="panel-collapse collapse" id="accordion<?php the_ID(); ?>">
                                    <div class="panel-body">
                                        <?php echo do_shortcode(wp_trim_words(get_the_content(), $attributes[ 'word_limit' ])); ?>
                                        <div class="readmore"><a
                                                href="<?php the_permalink(); ?>"><?php _e('More', EM_SHORTCODES_TEXTDOMAIN) ?></a>
                                        </div>
                                    </div>
                                    <!-- end of panel body -->
                                </div>
                            </div>

                            <?php
                            $increment++;
                        }
                    }
                    wp_reset_postdata();
                ?>
            </div>
        </div>
        <?php

        return ob_get_clean();
    }

    add_shortcode('accordion', 'hippo_shortcode_accordion');


