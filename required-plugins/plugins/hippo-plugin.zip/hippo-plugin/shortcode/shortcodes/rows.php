<?php

    function hippo_register_rows_shortcode($shortcode)
    {

        $register_row = array(
            'title'       => __('Row with column', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Generate row with column', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(
                'id'        => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Wrapper ID', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add wrapper id if use.', EM_SHORTCODES_TEXTDOMAIN),
                ),

                'gutter'    => array(
                    'type'        => 'select', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Add gutter class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add extra gutter controll class', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'no',
                    'options'     => array(
                        '0'               => ' - No - ',
                        'no-gutter'       => 'No Gutter'
                    )
                ),

                'class'     => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Wrapper Class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add wrapper class if use wrapper.', EM_SHORTCODES_TEXTDOMAIN),
                ),
                'container' => array(
                    'type'        => 'select', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Use Container', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add Container to row', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'no',
                    'options'     => array('yes' => 'Yes', 'no' => 'No')
                )
            )
        );

        $register_rowonly = array(
            'title'           => __('Row without column', EM_SHORTCODES_TEXTDOMAIN),
            'description'     => __('Generate row only without column', EM_SHORTCODES_TEXTDOMAIN),
            'editor_contents' => TRUE,
            'attributes'      => array(
                'id'        => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Wrapper ID', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add wrapper id if use.', EM_SHORTCODES_TEXTDOMAIN),
                ),

                'gutter'    => array(
                    'type'        => 'select', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Add gutter class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add extra gutter controll class', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'no',
                    'options'     => array(
                        '0'               => ' - No - ',
                        'no-gutter'       => 'No Gutter'
                    )
                ),

                'class'     => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Wrapper Class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add wrapper class if use wrapper.', EM_SHORTCODES_TEXTDOMAIN),
                ),
                'container' => array(
                    'type'        => 'select', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Use Container', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add Container to row', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'yes',
                    'options'     => array('yes' => 'Yes', 'no' => 'No')
                )
            )
        );

        $register_grid = array(
            'title'           => __('Grid / Column', EM_SHORTCODES_TEXTDOMAIN),
            'description'     => __('Generate Grid / Column', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'        => array('row'), // use if its a child
            'cloneable'       => TRUE, // use if its a child
            'editor_contents' => TRUE,
            'attributes'      => array(
                'col'        => array(
                    'type'        => 'select', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Grid', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select grid', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '12',
                    'options'     => array(
                        '1'  => 'Column 1',
                        '2'  => 'Column 2',
                        '3'  => 'Column 3',
                        '4'  => 'Column 4',
                        '5'  => 'Column 5',
                        '6'  => 'Column 6',
                        '7'  => 'Column 7',
                        '8'  => 'Column 8',
                        '9'  => 'Column 9',
                        '10' => 'Column 10',
                        '11' => 'Column 11',
                        '12' => 'Column 12'
                    )
                ),

                'class'      => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Column Class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add Column class if want.', EM_SHORTCODES_TEXTDOMAIN),
                ),

                'visibility' => array(
                    'type'        => 'select', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Visibility', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Visibility on various devices.', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '',
                    'options'     => array(
                        ''           => '- select -',
                        'visible-xs' => 'visible in small mobile',
                        'visible-sm' => 'visible in tablet ',
                        'visible-md' => 'visible in desktop',
                        'visible-lg' => 'visible in large from desktop',
                        'hidden-xs'  => 'hidden in small mobile',
                        'hidden-sm'  => 'hidden in tablet ',
                        'hidden-md'  => 'hidden in desktop',
                        'hidden-lg'  => 'hidden in large from desktop',

                    )
                )

            )

        );

        $shortcode->register('row', $register_row);
        $shortcode->register('rowonly', $register_rowonly);
        $shortcode->register('column', $register_grid);

    }

    add_action('hippo_register_shortcode', 'hippo_register_rows_shortcode');


    /**
     * Row shortcode
     */
    function hippo_shortcode_row($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'id'        => '',
            'class'     => '',
            'container' => 'no',
            'gutter'    => '0',
        ), $atts);

        ob_start();

        $write_id = (empty($attributes[ 'id' ])) ? '' : 'id="' . $attributes[ 'id' ] . '"';

        echo '<section class="' . $attributes[ 'class' ] . '" ' . $write_id . '>';

        if ($attributes[ 'container' ] == 'yes') {
            echo '<div class="container">';
        }

        if (empty($attributes[ 'gutter' ])) {
            echo '<div class="row">';
        } else {
            echo '<div class="row ' . $attributes[ 'gutter' ] . '">';
        }

        echo do_shortcode($contents);

        echo '</div>';

        if ($attributes[ 'container' ] == 'yes') {
            echo '</div>';
        }
        echo '</section>';

        return ob_get_clean();
    }

    add_shortcode('row', 'hippo_shortcode_row');
    add_shortcode('rowonly', 'hippo_shortcode_row');


    function hippo_shortcode_column($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'col'        => '12',
            'class'      => '',
            'visibility' => '',
        ), $atts);

        ob_start();

        $col = $attributes[ 'col' ];
        ?>
        <div
            class="<?php echo apply_filters('hippo_shortcode_column_class', 'col-md-' . $col . ' ' . $attributes[ 'visibility' ] . ' ' . $attributes[ 'class' ], $attributes) ?>">
            <?php
                echo do_shortcode($contents);
            ?>
        </div>
        <?php
        return ob_get_clean();
    }

    add_shortcode('column', 'hippo_shortcode_column');

