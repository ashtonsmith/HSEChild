<?php



function hippo_register_team_shortcode($shortcode)
{
    global $fontawesome_icons;

    $register_teams = array(
     'title'       => __('Teams', EM_SHORTCODES_TEXTDOMAIN),
     'description' => __('Teams', EM_SHORTCODES_TEXTDOMAIN),
     );


    $shortcode->register('teams', $register_teams);

    $register_team = array(
        'title'       => __('Team', EM_SHORTCODES_TEXTDOMAIN),
        'description' => __('Team', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'    => array('teams'), // use if its a child
            'cloneable'   => TRUE, // use if its a child
            'attributes'  => array(

                'image' => array(
                    'type'        => 'image',
                    'label'       => __('Member Photo', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Member photo here.', EM_SHORTCODES_TEXTDOMAIN)
                    ),

                'name' => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Member Name', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Member name', EM_SHORTCODES_TEXTDOMAIN)
                    ),
					
                'designation' => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Member Designation', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Member Designation', EM_SHORTCODES_TEXTDOMAIN)
                    ),

                )

            );

            $shortcode->register('team', $register_team);


        $register_team_social = array(
            'title'       => __('Team Social link', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Team social link', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'    => array('teams', 'team'), // use if its a child
            'cloneable'   => TRUE, // use if its a child
            'attributes'  => array(

                'icon' => array(
                    'type'        => 'icon',
                    'label'       => __('Social Icons', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Choose desire share icon', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => $fontawesome_icons
                ),

                'link' => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Social link', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Link of a social site', EM_SHORTCODES_TEXTDOMAIN)
                )
            )

        );

        $shortcode->register('teamsocial', $register_team_social);

}

add_action('hippo_register_shortcode', 'hippo_register_team_shortcode');


function hippo_shortcode_teams($atts, $contents = '')
{
	

    $attributes = shortcode_atts(array(), $atts);
    ob_start();
    ?>  
        
        <div class="member-wrapper">

			<?php
			   echo do_shortcode($contents);
			?>
					
		</div>
   <?php
   return ob_get_clean();
}

add_shortcode('teams', 'hippo_shortcode_teams');

function hippo_shortcode_team($atts, $contents = '')
{
    $attributes = shortcode_atts(array(
		'image' => '',
        'name' => '',
        'designation' => '',
        ), $atts);
    
    ob_start();
    ?>
	
    <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="thumbnail">
            <img alt="<?php echo $attributes ['name'] ?>" class="img-responsive" src="<?php echo $attributes ['image'] ?>">

            <div class="caption">
                <h3><?php echo $attributes ['name'] ?></h3>

                <p><?php echo $attributes['designation'] ?></p>
            </div>
            <div class="team-social">
                <ul class="list-inline">
                    <?php
                        echo do_shortcode($contents);
                    ?>
                </ul>
            </div>
        </div>
    </div>
	
<?php
return ob_get_clean();
}

add_shortcode('team', 'hippo_shortcode_team');


function hippo_shortcode_teamsocial($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'icon' => '',
            'link' => ''
        ), $atts);
        ob_start();
        ?>

        <li>
            <a href="<?php echo $attributes[ 'link' ] ?>" target="_blank">
                <i class="<?php echo $attributes[ 'icon' ] ?>"></i>
            </a>
        </li>
        <?php
        return ob_get_clean();
    }

    add_shortcode('teamsocial', 'hippo_shortcode_teamsocial');