<?php
    function hippo_register_category_news_shortcode($shortcode)
    {
        $register = array(
            'title'       => __('Category News', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Category News', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(

                'terms' => array(
                    'type'        => 'taxonomy', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Select Category', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select Category', EM_SHORTCODES_TEXTDOMAIN),
                    'taxonomy'    => 'category',
                    ),

                'limit'       => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Post limit', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Post limit', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '10'
                ),

                'word_limit'       => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Word limit', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put number of word', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '20'
                ),
            )
        );

        $shortcode->register('category-news', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_category_news_shortcode');


    function hippo_shortcode_category_news($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'terms'    => '',
            'limit'    => 10,
            'word_limit'    => 20,
        ), $atts);
        ob_start();

        $term_ids       = explode(',', $attributes[ 'terms' ]);


        ?>

						<div class="mag-category">
							<!-- magazine category title -->
							<div class="mag-cat-title">

								 <?php

								 foreach ($term_ids as $term_id) {
									$term = get_term($term_id, 'category');
									// $term_link = get_term_link( $term_id, 'category' );	
									?>
									<a href="<?php echo get_category_link( $term->term_id ) ?>">
										<strong><?php echo $term->name ?></strong> <i class="fa fa-arrow-circle-right"></i>	
									</a>

			                    <?php } ?>

								</div>
								<!-- magazine category article -->
								<div class="mag-cat-article">
									<div class="row mag-row"> 

							      
							<?php

								// WP_Query arguments


								$args = array(
									'posts_per_page' => $attributes['limit'],
									'post_type'      => 'post',
									'cat'  			 => $attributes['terms'],
									'post_status'    => 'publish',
									'post__not_in'   => get_option( 'sticky_posts' ),
									);

											// The Query
								$query = new WP_Query($args);
								$total_post = $query->post_count;

					

											// The Loop
								if ($query->have_posts()) {
									while ($query->have_posts()) {
										$query->the_post();
										$post     = get_post();

										?>



										<!-- category article item -->
										<div class="col-md-6 col-sm-6 col-xs-12">
											<div class="col-md-4">
												<div class="mag-cat-img">
													<?php the_post_thumbnail('category-post', array('class' => 'img-responsive')); ?>
												</div>
											</div>
											<div class="col-md-8">
												<div class="mag-cat-post">
													<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
													<div class="post-meta clearfix">
														<ul>
															<li><span class="author"><i class="fa fa-user"></i><?php the_author_posts_link(); ?></span></li>
															<li><span class="date"><i class="fa fa-calendar"></i><?php the_time('j F, Y') ?></span></li>
														</ul>
													</div>
													<p><?php echo wp_trim_words(get_the_content(), $attributes['word_limit']);?></p>
													
												</div>
											</div>
										</div>
																	

										<?php


									}
								}

								wp_reset_postdata();
								?>
										
							</div>
						</div>
					</div>
					<!-- //Magazine Category item -->



        <?php
        return ob_get_clean();
    }

    add_shortcode('category-news', 'hippo_shortcode_category_news');

