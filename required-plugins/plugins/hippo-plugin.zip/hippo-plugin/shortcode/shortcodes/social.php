<?php



    function hippo_register_social_shortcode($shortcode)
    {

        global $fontawesome_icons;

        $register_social = array(
            'title'       => __('Social links', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Social links', EM_SHORTCODES_TEXTDOMAIN),
        );


        $shortcode->register('social', $register_social);

        $register_social_link = array(
            'title'       => __('Social links', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Social links', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'    => array('social'), // use if its a child
            'cloneable'   => TRUE, // use if its a child
            'attributes'  => array(

                'icon' => array(
                    'type'        => 'icon',
                    'label'       => __('Social Icons', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Choose desire share icon', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => $fontawesome_icons
                ),

                'link' => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Social link', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Link of a social site', EM_SHORTCODES_TEXTDOMAIN)
                )
            )

        );

        $shortcode->register('social-link', $register_social_link);
    }

    add_action('hippo_register_shortcode', 'hippo_register_social_shortcode');


    function hippo_shortcode_social($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(), $atts);
        ob_start();
        ?>
        <div class="social-shares">
            <ul>
                <?php
                    echo do_shortcode($contents);
                ?>
            </ul>
        </div>
        <?php

        return ob_get_clean();
    }

    add_shortcode('social', 'hippo_shortcode_social');

    function hippo_shortcode_social_link($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'icon' => '',
            'link' => ''
        ), $atts);
        ob_start();
        ?>

        <li><a href="<?php echo $attributes['link'] ?>" target="_blank"><i class="<?php echo $attributes['icon'] ?>"></i></a></li>
        <?php
        return ob_get_clean();
    }

    add_shortcode('social-link', 'hippo_shortcode_social_link');









