<?php
// Pricing Table tinny

function hippo_register_pricing_table_shortcode($shortcode)
{


    $register_pricing_tables = array(
     'title'       => __('Pricing Table', EM_SHORTCODES_TEXTDOMAIN),
     'description' => __('Displaying Pricing Table', EM_SHORTCODES_TEXTDOMAIN),
     'attributes'  => array(
        'title' => array(
                    'type'        => 'text',
                    'label'       => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Table Title', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'Pricing table - Dynamic',
                    ),

                 
            )

     );

    $shortcode->register('pricing-tables', $register_pricing_tables);

    $register_pricing_table = array(
        'title'       => __('Pricing Table', EM_SHORTCODES_TEXTDOMAIN),
        'description' => __('Pricing Table', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'    => array('pricing-tables'), // use if its a child
            'cloneable'   => TRUE, // use if its a child
            'editor_contents' => TRUE,
            'attributes'  => array(

                'style'    => array(
                    'type'        => 'select',
                    'label'       => __('Style', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select your service style', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        'style1'   => __('Style one', EM_SHORTCODES_TEXTDOMAIN),
                        'style2'   => __('Style two', EM_SHORTCODES_TEXTDOMAIN),
                    ),

                    'condition'   => array(

                        'style1'   => array(
                            'show' => array('type', 'amount', 'duration', 'button_text', 'buttin_link', 'classes', 'featured'),
                            'hide' => array('description'),
                        ),

                        'style2'   => array(
                            'show' => array('type', 'description', 'amount', 'button_text', 'buttin_link', 'classes', 'featured'),
                            'hide' => array('duration'),
                        ),
                    ),


                ),


                'type' => array(
                    'type'        => 'text',
                    'label'       => __('Type', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Pricing type. e.g: Personal', EM_SHORTCODES_TEXTDOMAIN)
                    ),

                'description' => array(
                    'type'        => 'textarea', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Description', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Description', EM_SHORTCODES_TEXTDOMAIN)
                    ),

                'amount' => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Price', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Amount of Price', EM_SHORTCODES_TEXTDOMAIN)
                    ),

                'duration' => array(
                    'type'        => 'text',
                    'label'       => __('Duration', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Duration. e.g: 6 month', EM_SHORTCODES_TEXTDOMAIN)
                    ),

                'button_text' => array(
                    'type'        => 'text',
                    'label'       => __('Button Text', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Button Text', EM_SHORTCODES_TEXTDOMAIN)
                    ),
 
                'buttin_link' => array(
                    'type'        => 'text',
                    'label'       => __('Button Link', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Button Link', EM_SHORTCODES_TEXTDOMAIN)
                    ),

                'classes' => array(
                    'type'        => 'text',
                    'label'       => __('CSS Class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('CSS Class name', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     =>'col-md-4'
                    ),

                'featured' => array(
                    'type'        => 'select',
                    'label'       => __('featured', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Do you want to make this featured', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'no',
                    'options'     => array(
                        'yes'     => __('Yes', EM_SHORTCODES_TEXTDOMAIN), 
                        'no'      => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        )
                    ),

                )

            );

$shortcode->register('pricing-table', $register_pricing_table);
}

add_action('hippo_register_shortcode', 'hippo_register_pricing_table_shortcode');


function hippo_shortcode_pricing_tables($atts, $contents = '')
{
    
    $attributes = shortcode_atts(array(
        'title' => 'Pricing table - Dynamic',

        ), $atts);
    

    ob_start();
    ?>
    <div class="row pricing-table-wrapper">
        <div class="col-md-12"> 
            <h1 class="pricing-table-heading"><?php echo $attributes['title'] ?></h1>
        </div>

            <?php
                echo do_shortcode($contents);
            ?>
     </div>
   
    <?php
   return ob_get_clean();
}

add_shortcode('pricing-tables', 'hippo_shortcode_pricing_tables');

function hippo_shortcode_pricing_table($atts, $contents = '')
{

    $contents = trim($contents);

    $attributes = shortcode_atts(array(
        'style'         => 'style1',
        'type'          => '',
        'description'   => '',
        'amount'        => '',
        'duration'      => '',
        'button_text'   => '',
        'button_link'   => '',
        'classes'       =>'col-md-4',
        'featured'      =>'no'

        ), $atts);
    
    ob_start();
    ?>
    <div class="<?php echo $attributes['classes'] ?> col-sm-12 col-xs-12">


        <?php if ($attributes[ 'style' ] == 'style1') { ?>

           
           <?php  if ($attributes[ 'featured' ] == 'yes') {
                echo '<ul class="featured plan text-center">';
            }
            else {
                echo '<ul class="plan text-center">';
            }
            ?>
            <li class="plan-price"> 
                <p class="plane-name"><?php echo $attributes['type'] ?></p>
                <h2 class="plane-price"><?php echo $attributes['amount'] ?></h2>
                <span class="plane-duration"><?php echo $attributes['duration'] ?></span>
            </li>
            <?php echo do_shortcode($contents); ?>
            <li class="plan-action"><a href="<?php echo $attributes['button_link'] ?>" class="btn"><?php echo $attributes['button_text'] ?></a></li>
        </ul>


        <?php } elseif ($attributes[ 'style' ] == 'style2') { ?>

            <?php  if ($attributes[ 'featured' ] == 'yes') {
                echo '<ul class="featured static-plan text-center">';
            }
            else {
                echo '<ul class="static-plan text-center">';
            }
            ?>
                <li class="plan-price"> 
                    <h2 class="plane-name"><?php echo $attributes['type'] ?></h2>
                    <span class="plane-slogan"><?php echo $attributes['description'] ?></span>
                    
                </li>
                <?php echo do_shortcode($contents); ?>
                <li><span class="big-number"></sup><?php echo $attributes['amount'] ?></span></li>
                <li class="plan-action"><a href="<?php echo $attributes['button_link'] ?>" class="btn"><?php echo $attributes['button_text'] ?></a></li>
            </ul>

           <?php } ?>

    </div>
<?php
return ob_get_clean();
}
add_shortcode('pricing-table', 'hippo_shortcode_pricing_table');