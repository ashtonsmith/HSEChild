<?php

    function hippo_register_project_shortcode($shortcode)
    {
        $register = array(
            'title'       => __('Project', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Show Project Scroll', EM_SHORTCODES_TEXTDOMAIN),
            // 'editor_contents'=>true,
            'attributes'  => array(

                'style'        => array(
                    'type'        => 'select',
                    'label'       => __('Style', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select your service style', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        'style1' => __('Style1 for Home1', EM_SHORTCODES_TEXTDOMAIN),
                        'style2' => __('Style2 for Home2', EM_SHORTCODES_TEXTDOMAIN),
                        'style3' => __('Style3 for sidebar', EM_SHORTCODES_TEXTDOMAIN),
                        'style4' => __('Style4 for project page', EM_SHORTCODES_TEXTDOMAIN),
                    ),

                    'condition'   => array(

                        'style1' => array(
                            'show' => array('title', 'description', 'limit', 'terms', 'moretext'),
                            'hide' => array('grid_class'),
                        ),

                        'style2' => array(
                            'show' => array('limit', 'terms', 'moretext', 'grid_class'),
                            'hide' => array('title', 'grid_class', 'description'),
                        ),

                        'style3' => array(
                            'show' => array('limit', 'terms', 'moretext'),
                            'hide' => array('title', 'grid_class', 'description'),
                        ),

                        'style4' => array(
                            'show' => array('limit', 'terms', 'grid_class'),
                            'hide' => array('title', 'moretext', 'description'),
                        ),
                    ),


                ),


                'title'        => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => '',
                    'default'     => 'OUR PROJECT'
                ),

                'description'  => array(
                    'type'        => 'editor_contents', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Description', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put some description about project', EM_SHORTCODES_TEXTDOMAIN),
                ),

                'limit'        => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Project limit', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => '',
                    'default'     => '6'
                ),

                'terms'        => array(
                    'type'        => 'taxonomy', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Type', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Project Groups', EM_SHORTCODES_TEXTDOMAIN),
                    'taxonomy'    => 'project-type',
                    'multiple'    => TRUE
                ),
                'moretext'     => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('More text', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => '',
                    'default'     => 'More'
                ),

                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                ),

                'grid_class'   => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Grid Class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put Bootstrap grid class', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'col-md-4',
                ),

            )
        );

        $shortcode->register('project', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_project_shortcode');


    function hippo_shortcode_project($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'style'        => 'style1',
            'title'        => 'OUR PROJECTS',
            'description'  => '',
            'limit'        => '6',
            'terms'        => '',
            'moretext'     => 'More',
            'shadow_class' => '',
            'grid_class'   => 'col-md-4',

        ), $atts);

        $posts_per_page = $attributes[ 'limit' ];
        $term_ids       = explode(',', $attributes[ 'terms' ]);


        ob_start();
        ?>



        <?php if ($attributes[ 'style' ] == 'style1') { ?>

        <div class="project-box <?php echo $attributes[ 'shadow_class' ] ?>">
        <div class="product-slider">
        <h2 class="lead-title">
           <?php echo $attributes[ 'title' ] ?>

        </h2>
        <div class="lead-sub-title"><?php echo $attributes[ 'description' ] ?></div>

        <div class="css-product">

        <?php } elseif ($attributes[ 'style' ] == 'style2') { ?>



        <?php } elseif ($attributes[ 'style' ] == 'style3') { ?>

        <div class="about-sidebar">
        <ul class="project">

        <?php } elseif ($attributes[ 'style' ] == 'style4') { ?>

        <div>
        <ul id="filter">

            <li><a href="" class="active" data-group="all"><?php _e('All', EM_SHORTCODES_TEXTDOMAIN) ?></a></li>

            <?php
                foreach ($term_ids as $term_id) {
                    $term = get_term($term_id, 'project-type');
                    ?>
                    <li><a href="" data-group="<?php echo $term->slug ?>"><?php echo $term->name ?></a></li>

                <?php } ?>

        </ul>


        <div id="grid">

            <?php } ?>


            <?php
                // WP_Query arguments
                $args = array(
                    'posts_per_page' => $posts_per_page,
                    'post_type'      => 'project',
                    'post_status'    => 'publish',
                    'orderby'        => 'menu_order',
                    'order'          => 'ASC',
                    'tax_query'      => array(
                        array(
                            'taxonomy' => 'project-type',
                            'field'    => 'id',
                            'terms'    => $term_ids,
                            'operator' => 'IN'
                        )
                    )
                );

                // The Query
                $query = new WP_Query($args);
                $total_post = $query->post_count;

                if ($attributes[ 'style' ] == 'style4') {
                    $post_increment = 1;
                }


                // The Loop
                if ($query->have_posts()) {
                    while ($query->have_posts()) {
                        $query->the_post();
                        $post = get_post();

                        $terms = wp_get_post_terms(get_the_ID(), 'project-type');


                        if ($attributes[ 'style' ] == 'style4') {
                            $thumb_id = get_post_meta(get_the_ID(), 'project_thumb', TRUE);
                            $thumb    = wp_get_attachment_image($thumb_id, 'project-thumb', 0, array(

                                'class' => 'img-responsive',
                                'alt'   => get_the_title()

                            ));

                            $terms = wp_get_post_terms(get_the_ID(), 'project-type');

                            $term = array();
                            foreach ($terms as $t) {
                                $term[ ] = '"' . $t->slug . '"';
                            }

                        }


                        ?>


                        <?php if ($attributes[ 'style' ] == 'style1') { ?>

                            <div class="product-item">
                                <?php the_post_thumbnail('project-thumb', array('class' => 'imgthumb')); ?>
                                <div class="single-product">
                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                    <?php

                                        echo hippo_before_more_content($post->post_content);
                                    ?>
                                    <div class="readmore">
                                        <a href="<?php the_permalink(); ?>"><?php _e($attributes[ 'moretext' ], HIPPO_TEXTDOMAIN) ?></a>
                                    </div>
                                </div>
                            </div>

                        <?php } elseif ($attributes[ 'style' ] == 'style2') { ?>

                            <div class="col-md-3 col-sm-6 col-xs-12 project-style2 no-right-gutter">

                                    <article class="<?php echo $attributes[ 'shadow_class' ] ?>">

                                        <?php if (has_post_thumbnail()) { ?>

                                            <header>
                                                <?php the_post_thumbnail('project-thumb2', array('class' => 'imgthumb')); ?>
                                            </header>

                                        <?php } ?>

                                        <div class="single-promo">
                                            <h2><?php the_title(); ?></h2>
                                            <?php echo hippo_before_more_content($post->post_content); ?>
                                            <a href="<?php the_permalink(); ?>"
                                               class="readmore-button"><?php _e($attributes[ 'moretext' ], HIPPO_TEXTDOMAIN) ?></a>
                                        </div>
                                    </article>

                            </div>

                        <?php } elseif ($attributes[ 'style' ] == 'style3') { ?>

                            <li>
                                <?php if (has_post_thumbnail()) { ?>

                                    <header>
                                        <?php the_post_thumbnail('project-sidebar-thumb', array('class' => 'img-responsive')); ?>
                                    </header>

                                <?php } ?>

                                <h4><?php the_title(); ?></h4>

                                <p><?php echo hippo_before_more_content($post->post_content); ?></p>
                                <a href="<?php the_permalink(); ?>"
                                   readmore-button""><?php _e($attributes[ 'moretext' ], HIPPO_TEXTDOMAIN) ?></a>
                            </li>

                        <?php } elseif ($attributes[ 'style' ] == 'style4') { ?>

                            <div class="item <?php echo $attributes[ 'grid_class' ] ?>"
                                 data-groups='[<?php echo implode(',', $term); ?>]'>
                                <div class="project-item">
                                    <div class="project-image-container">
                                        <?php
                                            if (has_post_thumbnail()) {

                                                echo get_the_post_thumbnail($post->ID, 'project-thumb3', array('class' => 'img-responsive'));
                                            }?>

                                        <?php
                                            if (has_post_thumbnail()) {
                                                $large_image_url = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'large');
                                                ?>

                                                <div class="project-plus-btn">
                                            <span><a href="<?php echo $large_image_url[ 0 ]; ?>"
                                                     class="fa fa-plus"></a></span>
                                                </div>

                                            <?php } ?>

                                        <div class="project-link-btn">
                                            <span><a href="<?php the_permalink(); ?>"
                                                     class="fa fa-link"></a></span>
                                        </div>
                                    </div>

                                    <div class="project-details">
                                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

                                        <?php echo hippo_before_more_content($post->post_content); ?>
                                        <a href="<?php the_permalink(); ?>"
                                           class="readmore"><?php _e('Read More', HIPPO_TEXTDOMAIN) ?></a>

                                    </div>
                                </div>
                            </div>

                            <?php

                            if ($post_increment == $posts_per_page) {
                                break;
                            }

                            $post_increment++;

                        }


                    }
                }

                wp_reset_postdata();
            ?>


            <?php if ($attributes[ 'style' ] == 'style1'){ ?>
        </div> <!-- .css-product -->
        <div class="customNavigation css-product-navigation">
            <a class="next"><i class="fa fa-angle-right"></i></a>
            <a class="prev"><i class="fa fa-angle-left"></i></a>
        </div>

        </div> <!-- .product-slider -->
    </div>
        <?php } ?>

        <?php if ($attributes[ 'style' ] == 'style2'){ ?>

        <?php } ?>

        <?php if ($attributes[ 'style' ] == 'style3'){ ?>
        </ul>
        </div>
        <?php } ?>

        <?php if ($attributes[ 'style' ] == 'style4') { ?>
        </div>
        <!-- #grid -->
        </div>
        <?php } ?>


        <?php

        return ob_get_clean();
    }

    add_shortcode('project', 'hippo_shortcode_project');