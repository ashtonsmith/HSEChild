<?php



function hippo_register_button_shortcode($shortcode)
{
    global $fontawesome_icons;

    $register_button = array(
        'title'       => __('Button', EM_SHORTCODES_TEXTDOMAIN),
        'description' => __('Display button', EM_SHORTCODES_TEXTDOMAIN),
        'attributes'  => array(

            'style'    => array(
                    'type'        => 'select',
                    'label'       => __('Style', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select button style', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        'simple-btn'   => __('Simple style', EM_SHORTCODES_TEXTDOMAIN),
                        'rounded-btn'   => __('Rounded style', EM_SHORTCODES_TEXTDOMAIN),
                        'simple-icon-btn'   => __('Simple icon style', EM_SHORTCODES_TEXTDOMAIN),
                        'rounded-icon-btn'   => __('Rounded & icon style', EM_SHORTCODES_TEXTDOMAIN),
                        'only-border-btn'   => __('Only Border style', EM_SHORTCODES_TEXTDOMAIN),
                        'border-icon-btn'   => __('Border & icon style', EM_SHORTCODES_TEXTDOMAIN),
                    ),

                    'condition'   => array(

                        'simple-btn'   => array(
                            'show' => array('text', 'button_link', 'type', 'bg_color', 'text_color'),
                            'hide' => array('icon'),
                        ),

                        'rounded-btn'   => array(
                            'show' => array('text', 'button_link', 'type', 'bg_color', 'text_color'),
                            'hide' => array('icon'),
                        ),

                        'simple-icon-btn'   => array(
                            'show' => array('text', 'button_link', 'type', 'icon', 'bg_color', 'text_color'),
                            'hide' => array(''),
                        ),

                        'rounded-icon-btn'   => array(
                            'show' => array('text', 'button_link', 'type', 'icon', 'bg_color', 'text_color'),
                            'hide' => array(''),
                        ),

                        'only-border-btn'   => array(
                            'show' => array('text', 'button_link', 'type', 'text_color'),
                            'hide' => array('icon', 'bg_color'),
                        ),

                        'border-icon-btn'   => array(
                            'show' => array('text', 'button_link', 'type', 'icon', 'text_color'),
                            'hide' => array('bg_color'),
                        ),
                    ),


                ),

            
            'text' => array(
                'type'        => 'text',
                'label'       => __('Text', EM_SHORTCODES_TEXTDOMAIN),
                'description' => __('Button Text', EM_SHORTCODES_TEXTDOMAIN)
                ),

            'button_link' => array(
                'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                'label'       => __('Link', EM_SHORTCODES_TEXTDOMAIN),
                'description' => __('Button Link', EM_SHORTCODES_TEXTDOMAIN)
                ), 

            'type' => array(
                'type'        => 'select',
                'label'       => __('Type', EM_SHORTCODES_TEXTDOMAIN),
                'description' => __('Button type',EM_SHORTCODES_TEXTDOMAIN),
                'options'=>array(
                    'small-btn'=>__('Small Button', EM_SHORTCODES_TEXTDOMAIN),
                    'medium-btn'=>__('Medium Button', EM_SHORTCODES_TEXTDOMAIN), 
                    'large-btn'=>__('Large Button', EM_SHORTCODES_TEXTDOMAIN), 
                    )
                ),

            'icon' => array(
                    'type'        => 'icon',
                    'label'       => __('Social Icons', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Choose desire button icon', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => $fontawesome_icons
                ),

            'bg_color' => array(
                    'type'        => 'color', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Background color', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select background color', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '#e74c3c',

                ),

            'text_color' => array(
                    'type'        => 'color', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Text color', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select text color', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '#FFFFFF',

                ),


            )

);

$shortcode->register('button', $register_button);

}

add_action('hippo_register_shortcode', 'hippo_register_button_shortcode');


function hippo_shortcode_button($atts, $contents = '')
{
    $attributes = shortcode_atts(array(
        'style' => 'simple-btn',
        'text' => '',
        'button_link' => '',
        'type' => '',
        'icon' => '',
        'bg_color' => '',
        'text_color' => '',
        ), $atts);
    
    ob_start();
    ?>



    <?php if ($attributes['style'] == 'simple-btn'){ ?>

        <div class="btn-wrapper simple-btn <?php echo $attributes['type'] ?>">
            <a style="background-color:<?php echo $attributes['bg_color'] ?>; color:<?php echo $attributes['text_color'] ?>" href="<?php echo $attributes['button_link'] ?>"><?php echo $attributes['text'] ?></a>
        </div>
       
    <?php } elseif ($attributes['style'] == 'rounded-btn'){ ?>

        <div class="btn-wrapper rounded-btn <?php echo $attributes['type'] ?>">
            <a style="background-color:<?php echo $attributes['bg_color'] ?>; color:<?php echo $attributes['text_color'] ?>" href="<?php echo $attributes['button_link'] ?>"><?php echo $attributes['text'] ?></a>
        </div>
         
    <?php } elseif ($attributes['style'] == 'simple-icon-btn'){ ?>

        <div class="btn-wrapper simple-icon-btn <?php echo $attributes['type'] ?>">
            <a style="background-color:<?php echo $attributes['bg_color'] ?>; color:<?php echo $attributes['text_color'] ?>" href="<?php echo $attributes['button_link'] ?>"><i class="<?php echo $attributes['icon'] ?>"></i> <?php echo $attributes['text'] ?></a>
        </div>
    
    <?php } elseif ($attributes['style'] == 'only-border-btn'){ ?>
    
        <div class="btn-wrapper only-border-btn <?php echo $attributes['type'] ?>">
            <a style="background-color:<?php echo $attributes['bg_color'] ?>; color:<?php echo $attributes['text_color'] ?>" href="<?php echo $attributes['button_link'] ?>"><?php echo $attributes['text'] ?></a>
        </div>
    
    <?php } elseif ($attributes['style'] == 'rounded-icon-btn'){ ?>

        <div class="btn-wrapper rounded-btn <?php echo $attributes['type'] ?>">
            <a style="background-color:<?php echo $attributes['bg_color'] ?>; color:<?php echo $attributes['text_color'] ?>" href="<?php echo $attributes['button_link'] ?>"><i class="<?php echo $attributes['icon'] ?>"></i> <?php echo $attributes['text'] ?></a>
        </div>

    <?php } elseif ($attributes['style'] == 'border-icon-btn'){ ?>

        <div class="btn-wrapper only-border-btn <?php echo $attributes['type'] ?>">
            <a style="background-color:<?php echo $attributes['bg_color'] ?>; color:<?php echo $attributes['text_color'] ?>" href="<?php echo $attributes['button_link'] ?>"><i class="<?php echo $attributes['icon'] ?>"></i> <?php echo $attributes['text'] ?></a>
        </div>

    <?php } ?>

    
    <?php
    return ob_get_clean();
}

add_shortcode('button', 'hippo_shortcode_button');