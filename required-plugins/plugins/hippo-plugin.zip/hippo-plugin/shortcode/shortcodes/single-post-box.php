<?php

    function hippo_register_welcome_post_shortcode($shortcode)
    {
        $register = array(
            'title'       => __('Single Post box', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Show a single post on box', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(
                'post'         => array(
                    'type'        => 'post', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Post', EM_SHORTCODES_TEXTDOMAIN),
                    'post_type'   => 'post',
                    'description' => '',
                ),

                'moretext'     => array(
                    'type'        => 'text',
                    'label'       => __('Read More text', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('To Show Read More text', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'More'
                ),

                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                ),

                'class'     => array(
                    'type'        => 'text',
                    'label'       => __('Extra Class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add extra class', EM_SHORTCODES_TEXTDOMAIN),
                ),

            )
        );

        $shortcode->register('single-post-box', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_welcome_post_shortcode');


    function hippo_shortcode_welcome_post($atts, $contents = '')
    {

        $attributes = shortcode_atts(array(
            'post'     => '0',
            'shadow_class'     => '',
            'class'     => '',
            'moretext' => 'More'
        ), $atts);

        ob_start();
        ?>
            <div class="<?php echo $attributes[ 'class' ].' '.$attributes[ 'shadow_class' ] ?> single-post-box">

                <?php

                    // WP_Query arguments

                    $args = array(
                        'p'           => $attributes[ 'post' ],
                        'post_type'   => 'post',
                        'post_status' => 'publish'
                    );

                    // The Query
                    $query = new WP_Query($args);


                    $total_post = $query->post_count;


                    // The Loop
                    if ($query->have_posts()) {


                        global $more; // Declare global $more (before the loop).
                        //$old_more = $more;
                        //$more = 0;

                        while ($query->have_posts()) {
                            $query->the_post();

                            $post = get_post();
                            ?>

                            <article>
                                <?php if (has_post_thumbnail()) { ?>

                                    <header>
                                        <?php the_post_thumbnail('welcome-post-thumb', array('class' => 'imgthumb')); ?>
                                    </header>

                                <?php } ?>

                                <div class="welcome-text">
                                    <h2><?php the_title(); ?></h2>
                                    <?php
                                        echo hippo_before_more_content($post->post_content);
                                    ?>
                                    <div class="readmore"><a
                                            href="<?php the_permalink(); ?>"><?php _e($attributes[ 'moretext' ], EM_SHORTCODES_TEXTDOMAIN) ?></a>
                                    </div>
                                </div>
                            </article>
                        <?php
                        }
                        //$more = $old_more;
                    }
                    wp_reset_postdata();
                ?>
            </div>
        <?php
        return ob_get_clean();
    }

    add_shortcode('single-post-box', 'hippo_shortcode_welcome_post');


