<?php

function hippo_register_slider_shortcode($shortcode)
{
    $register = array(
        'title'       => __('Magazine Slider', EM_SHORTCODES_TEXTDOMAIN),
        'description' => __('Magazine Slider', EM_SHORTCODES_TEXTDOMAIN),
        'attributes'  => array(

                'post'    => array(
                    'type'        => 'post', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Post', EM_SHORTCODES_TEXTDOMAIN),
                    'post_type'   => 'post',
                    'description' => '',
                    'multiple'    => TRUE
                    ),
            )
        );

    $shortcode->register('slider', $register);
}

add_action('hippo_register_shortcode', 'hippo_register_slider_shortcode');


function hippo_shortcode_slider($atts, $contents = '')
{
    $attributes = shortcode_atts(array(
        'post'    => '0',

        ), $atts);



    ob_start();


    ?>

	<!-- Magazine Featured carousel -->
	<div class="magazine-carousel">
		
		<div id="magazine-slider" class="carousel slide magazine-slider" data-ride="carousel">

		    <!-- Wrapper for slides -->
			<div class="carousel-inner">

   
        <?php

        // WP_Query arguments

        $args = array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'post__in'       => explode(',', $attributes['post']),
            'post__not_in'   => get_option( 'sticky_posts' ),
            'has_password'   => false,
            );

            // The Query
            $query = new WP_Query($args);

            $total_post = $query->post_count;

        // The Loop
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $post     = get_post();
             
             ?>
                        

                <div class="item">
                	<?php if( has_post_thumbnail() ){ ?>
                        <?php the_post_thumbnail('slider-img', array('class' => 'img-responsive')); ?>
                    <?php } ?>
					<!-- carousel caption -->
					<div class="carousel-caption">
						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<div class="post-meta">
							<ul>
								<li><span class="category"><?php echo get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', EM_SHORTCODES_TEXTDOMAIN ) ); ?></span></li>
								<li><i class="fa fa-user"></i><span class="author"><?php the_author_posts_link(); ?></span></li>
								<li><i class="fa fa-calendar"></i> <?php the_time('j F, Y') ?></li>
							</ul>
						</div>
					</div>
				</div>

                <?php

            }
        }

        wp_reset_postdata();
        ?>

			</div>

			  <!-- Controls -->
		  	<a class="left carousel-control" href="#magazine-slider" data-slide="prev">
				<i class="fa fa-angle-left"></i>
		  	</a>
		  	<a class="right carousel-control" href="#magazine-slider" data-slide="next">
				<i class="fa fa-angle-right"></i>
		  	</a>
		</div>
	</div>


<?php

return ob_get_clean();
}

add_shortcode('slider', 'hippo_shortcode_slider');