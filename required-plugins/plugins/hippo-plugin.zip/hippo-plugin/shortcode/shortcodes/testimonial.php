<?php



    function hippo_register_testimonial_shortcode($shortcode)
    {

        $register_testimonials = array(
            'title'       => __('Testimonials', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Testimonial list', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(
                'title'        => array(
                    'type'        => 'text',
                    'label'       => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Testimonial Title', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'Our Client say\'s',
                ),
                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                ),
            )
        );


        $shortcode->register('testimonials', $register_testimonials);

        $register_testimonial = array(
            'title'       => __('Testimonial', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Testimonial', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'    => array('testimonials'), // use if its a child
            'cloneable'   => TRUE, // use if its a child
            'attributes'  => array(

                'text'        => array(
                    'type'        => 'textarea',
                    'label'       => __('Testimonial Text', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Your testimonial text here', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'image'       => array(
                    'type'        => 'image',
                    'label'       => __('Client logo', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Client logo. Dimension: 100px &times; 100px', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'name'        => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Client Name', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Client name', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'designation' => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Client Designation', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Client Designation', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'company'     => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Client company name', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Client company name', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'link'        => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Client company web link', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Client company web link', EM_SHORTCODES_TEXTDOMAIN)
                ),
            )

        );

        $shortcode->register('testimonial', $register_testimonial);

    }

    add_action('hippo_register_shortcode', 'hippo_register_testimonial_shortcode');


    function hippo_shortcode_testimonials($atts, $contents = '')
    {


        $attributes = shortcode_atts(array(
            'title' => 'Our Client say\'s',
            'shadow_class' => '',
        ), $atts);
        ob_start();
        ?>

        <div class="testimonial-box <?php echo $attributes [ 'shadow_class' ] ?>">
            <h2 class="lead-title"><?php echo $attributes [ 'title' ] ?></h2>

            <div class="client-testimonial-caruosel">
                <div class="client-testimonial">
                    <?php echo do_shortcode($contents); ?>
                </div>
                <div class="customNavigation client-testimonial-navigation">
                    <a class="next"><i class="fa fa-angle-right"></i></a>
                    <a class="prev"><i class="fa fa-angle-left"></i></a>
                </div>
            </div>
        </div>

        <?php
        return ob_get_clean();
    }

    add_shortcode('testimonials', 'hippo_shortcode_testimonials');

    function hippo_shortcode_testimonial($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'text'        => '',
            'image'       => '',
            'name'        => '',
            'designation' => '',
            'company'     => '',
            'link'        => '',
        ), $atts);

        ob_start();
        ?>

        <div class="item">
            <div class="testimonial">
                <p><i class="fa fa-quote-left"></i> <?php echo $attributes [ 'text' ] ?> <i
                        class="fa fa-quote-right"></i></p>
            </div>

            <img src="<?php echo $attributes[ 'image' ] ?>" alt=""/>
            <span class="name"> <?php echo $attributes[ 'name' ] ?>, <span
                    class="position"><?php echo $attributes[ 'designation' ] ?></span></span>

            <span class="company"><a
                    href="<?php echo $attributes[ 'link' ] ?>"><?php echo $attributes[ 'company' ] ?></a></span>

        </div>

        <?php
        return ob_get_clean();
    }

    add_shortcode('testimonial', 'hippo_shortcode_testimonial');