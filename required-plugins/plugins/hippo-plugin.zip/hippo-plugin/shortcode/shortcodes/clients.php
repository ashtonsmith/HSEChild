<?php



    function hippo_register_clients_shortcode($shortcode)
    {


        $register_clients = array(
            'title'       => __('Clients', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Clients list', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(
                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                )
            )
        );


        $shortcode->register('clients', $register_clients);

        $register_client = array(
            'title'       => __('Client', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Client', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'    => array('clients'), // use if its a child
            'cloneable'   => TRUE, // use if its a child
            'attributes'  => array(

                'logo' => array(
                    'type'        => 'image',
                    'label'       => __('Client logo', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Client logo. Dimension: 100px &times; 100px', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'link' => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Client Site link', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Client Website link', EM_SHORTCODES_TEXTDOMAIN)
                ),


            )

        );

        $shortcode->register('clients', $register_client);
    }

    add_action('hippo_register_shortcode', 'hippo_register_clients_shortcode');


    function hippo_shortcode_clients($atts, $contents = '')
    {
        $attributes = shortcode_atts(array( 'shadow_class' => ''), $atts);
        ob_start();
        ?>
        <div class="clients <?php echo $attributes[ 'shadow_class' ] ?>">
            <?php
                echo do_shortcode($contents);
            ?>
        </div>
        <?php
        return ob_get_clean();
    }

    add_shortcode('clients', 'hippo_shortcode_clients');

    function hippo_shortcode_client($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'logo' => '',
            'link' => ''
        ), $atts);
        ob_start();
        ?>
        <div class="col-md-2 col-sm-3 col-xs-4">

            <?php if (!empty($attributes[ 'link' ])){ ?>
            <a href="<?php echo $attributes[ 'link' ] ?>">
                <?php } ?>
                <img src="<?php echo $attributes[ 'logo' ] ?>" alt="">
                <?php if (!empty($attributes[ 'link' ])){ ?>
            </a>
        <?php } ?>
        </div>
        <?php
        return ob_get_clean();
    }

    add_shortcode('clients', 'hippo_shortcode_client');









