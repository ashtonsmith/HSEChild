<?php



    function hippo_register_skills_shortcode($shortcode)
    {


        $register_skills = array(
            'title'       => __('Skills', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Skills Progress Bar', EM_SHORTCODES_TEXTDOMAIN),

               
        );

        $shortcode->register('skills', $register_skills);


        $register_skill = array(
            'title'       => __('Skill', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Skill progress', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'    => array('skills'), // use if its a child
            'cloneable'   => TRUE, // use if its a child
            'attributes'  => array(

                'title'   => array(
                    'type'        => 'text',
                    'label'       => __('Name', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Name of a skill', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'percent' => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Percent', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '50',
                    'description' => __('Skill in percent. 1 to 100', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'type' => array(
                    'type'        => 'select',
                    'label'       => __('Type', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Choose progress type', EM_SHORTCODES_TEXTDOMAIN),
                    'options'=>array('progress-bar-danger'=>'Danger', 'progress-bar-info'=>'Info', 'progress-bar-success'=>'Success')
                    )
                

            )

        );

        $shortcode->register('skill', $register_skill);
    }

    add_action('hippo_register_shortcode', 'hippo_register_skills_shortcode');


    function hippo_shortcode_skills($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(), $atts);
        ob_start();
        ?>

        <div class="progress-rapper">
            <?php
                echo do_shortcode($contents);
            ?>
        </div>

        <?php

        return ob_get_clean();
    }

    add_shortcode('skills', 'hippo_shortcode_skills');

    function hippo_shortcode_skill($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'title'   => '',
            'percent' => '',
            'type' => '',
        ), $atts);
        ob_start();
        ?>
            <h4><?php echo $attributes[ 'title' ] ?></h4>
            <div class="progress">  			
                <div style="width: <?php echo $attributes[ 'percent' ] ?>%;" class="progress-bar <?php echo $attributes[ 'type' ] ?>">
                    <span class="sr-only"></span>
                </div>
            </div>
			
        <?php
        return ob_get_clean();
    }

    add_shortcode('skill', 'hippo_shortcode_skill');









