<?php


    function hippo_register_support_shortcode($shortcode)
    {


        $register_supports = array(
            'title'       => __('Supports', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Supports', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(
                'style' => array(
                    'type'        => 'select',
                    'label'       => __('Style', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select your service style', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        'style1' => __('Style one', EM_SHORTCODES_TEXTDOMAIN),
                        'style2' => __('Style two', EM_SHORTCODES_TEXTDOMAIN),
                    ),

                    'child_also'  => TRUE,

                    'condition'   => array(

                        'style1' => array(
                            'show' => array('type', 'support_lavel', 'status', 'bg_color', 'grid_class'),
                            'hide' => array(''),
                        ),

                        'style2' => array(
                            'show' => array('type', 'support_lavel', 'status', 'bg_color'),
                            'hide' => array('grid_class'),
                        ),
                    )

                )
            )

        );


        $shortcode->register('supports', $register_supports);

        $register_support = array(
            'title'           => __('support', EM_SHORTCODES_TEXTDOMAIN),
            'description'     => __('support', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'        => array('supports'), // use if its a child
            'cloneable'       => TRUE, // use if its a child
            'editor_contents' => TRUE,
            'attributes'      => array(


                'type'          => array(
                    'type'        => 'text',
                    'label'       => __('Query type', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Support type', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'support_lavel' => array(
                    'type'        => 'text',
                    'label'       => __('Support Lavel', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put your support lavel', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '100%',
                ),

                'status'        => array(
                    'type'        => 'text',
                    'label'       => __('Status', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put your support status', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'bg_color'      => array(
                    'type'        => 'color', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Background color', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select background color', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => '#3e9b52',

                ),

                'grid_class'    => array(
                    'type'        => 'text',
                    'label'       => __('Bootstrap Grid Class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put bootstrap grid class', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'col-md-4',
                ),

            )

        );

        $shortcode->register('support', $register_support);

    }

    add_action('hippo_register_shortcode', 'hippo_register_support_shortcode');


    $_hippo_supports_attr = array();

    function hippo_shortcode_supports($atts, $contents = '')
    {

        global $_hippo_supports_attr;

        $attributes = shortcode_atts(array(

            'style' => 'style1',

        ), $atts);

        $_hippo_supports_attr = $attributes;

        ob_start();
        ?>

        <div class="support-wrapper clearfix">


            <?php if ($attributes[ 'style' ] == 'style1'){ ?>


            <div class="support-policy row">

                <?php } elseif ($attributes[ 'style' ] == 'style2'){ ?>

                <div class="support-policy support-style">
                    <div class="row-heading">
                        <div class="col-md-2 text-center"><?php _e('Query type', EM_SHORTCODES_TEXTDOMAIN) ?></div>
                        <div class="col-md-6"><?php _e('Details', EM_SHORTCODES_TEXTDOMAIN) ?></div>
                        <div
                            class="col-md-2 text-center"><?php _e('Support level', EM_SHORTCODES_TEXTDOMAIN) ?></div>
                        <div class="col-md-2 text-center"><?php _e('Status', EM_SHORTCODES_TEXTDOMAIN) ?></div>
                    </div>


                    <?php } ?>


                    <?php
                        echo do_shortcode($contents);
                    ?>

                    <?php if ($attributes[ 'style' ] == 'style2'){ ?>
                </div>

                <?php }elseif ($attributes[ 'style' ] == 'style1'){ ?>
            </div>
        <?php } ?>

        </div> <!-- .support-wrapper -->
        <?php
        return ob_get_clean();
    }

    add_shortcode('supports', 'hippo_shortcode_supports');

    function hippo_shortcode_support($atts, $contents = '')
    {


        global $_hippo_supports_attr;

        $attributes = shortcode_atts(array(

            'type'          => '',
            'support_lavel' => '100%',
            'status'        => '',
            'bg_color'      => '#3e9b52',
            'grid_class'    => 'col-md-4',
        ), $atts);

        ob_start();
        ?>


        <?php if ($_hippo_supports_attr[ 'style' ] == 'style1') { ?>
        <!-- support style one -->
        <div class="<?php echo $attributes[ 'grid_class' ] ?> col-sm-6 col-xs-12">
            <div class="policy-item">
                <div class="col-type">
                    <h3><?php echo $attributes[ 'type' ] ?></h3>
                </div>
                <div class="col-detail">
                    <p><?php echo do_shortcode($contents); ?></p>
                </div>
                <div class="col-level" style="background-color:<?php echo $attributes[ 'bg_color' ] ?>">
                    <div class="level-info">
                        <span class="count-up"><?php echo $attributes[ 'support_lavel' ] ?></span>
                    </div>
                    <strong><?php echo $attributes[ 'status' ] ?></strong>
                </div>
            </div>
        </div> <!-- /Support style one -->
    <?php } elseif ($_hippo_supports_attr[ 'style' ] == 'style2') { ?>


        <div class="row-body">
            <div class="col-md-2 col-type"><?php echo $attributes[ 'type' ] ?></div>
            <div class="col-md-6 col-detail"><?php echo do_shortcode($contents); ?></div>
            <div class="col-md-2 col-level"><span
                    class="number"><?php echo $attributes[ 'support_lavel' ] ?></span></div>
            <div class="col-md-2 col-status" style="background-color:<?php echo $attributes[ 'bg_color' ] ?>">
                <strong><?php echo $attributes[ 'status' ] ?></strong></div>
        </div>
        <!-- .row-body -->
    <?php } ?>

        <?php
        return ob_get_clean();
    }

    add_shortcode('support', 'hippo_shortcode_support');