<?php
    function hippo_register_partner_carousel_shortcode($shortcode)
    {
        $partner_carousels = array(
            'title'       => __('Partner Carousels', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Carousel item', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(
                'title'        => array(
                    'type'        => 'text',
                    'label'       => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'OUR PARTNER',
                ),

                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                )
            )
        );

        $shortcode->register('partner-carousels', $partner_carousels);

        $register_partner_carousel = array(
            'title'       => __('Partner carousel', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Partner carousel', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'    => array('partner-carousels'), // use if its a child
            'cloneable'   => TRUE, // use if its a child
            'attributes'  => array(

                'logo' => array(
                    'type'        => 'image',
                    'label'       => __('Partner Logo', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Partner. Dimension: 165px &times; 60px', EM_SHORTCODES_TEXTDOMAIN)
                ),

                'link' => array(
                    'type'        => 'text',
                    'label'       => __('Partner web link', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Partner web link. e.g: http://themehippo.com', EM_SHORTCODES_TEXTDOMAIN)
                ),
            )

        );

        $shortcode->register('partner-carousel', $register_partner_carousel);
    }

    add_action('hippo_register_shortcode', 'hippo_register_partner_carousel_shortcode');


    function hippo_shortcode_partner_carousels($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'title' => 'OUR PARTNER',
            'shadow_class' => '',
        ), $atts);
        ob_start();
        ?>
        <div class="partners-caruosel-box <?php echo $attributes[ 'shadow_class' ] ?>">
            <h3><?php echo $attributes[ 'title' ] ?></h3>

            <div class="partners-caruosel-container">
                <div class="partners-caruosel">
                    <?php
                        echo do_shortcode($contents);
                    ?>
                </div>
                <div class="customNavigation partners-caruosel-navigation">
                    <a class="next"><i class="fa fa-angle-right"></i></a>
                    <a class="prev"><i class="fa fa-angle-left"></i></a>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    add_shortcode('partner-carousels', 'hippo_shortcode_partner_carousels');

    function hippo_shortcode_partner_carousel($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'logo' => '',
            'link' => ''
        ), $atts);
        ob_start();
        ?>

        <!-- item -->
        <div class="item">

            <?php if (!empty($attributes[ 'link' ])){ ?>
            <a href="<?php echo $attributes[ 'link' ] ?>">
                <?php } ?>
                <img src="<?php echo $attributes[ 'logo' ] ?>" alt="">
                <?php if (!empty($attributes[ 'link' ])){ ?>
            </a>
        <?php } ?>
        </div>

        <?php
        return ob_get_clean();
    }

    add_shortcode('partner-carousel', 'hippo_shortcode_partner_carousel');