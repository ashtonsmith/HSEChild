<?php

    function hippo_register_services_shortcode($shortcode)
    {
        $register = array(
            'title'       => __('Services', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Service list', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(

                'style'        => array(
                    'type'        => 'select',
                    'label'       => __('Style', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select your service style', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        'style1' => __('Style one', EM_SHORTCODES_TEXTDOMAIN),
                        'style2' => __('Style two', EM_SHORTCODES_TEXTDOMAIN),
                    ),

                    'condition'   => array(

                        'style1' => array(
                            'show' => array('post'),
                            'hide' => array('grid_class'),
                        ),

                        'style2' => array(
                            'show' => array('post', 'grid_class'),
                            'hide' => array('row'),
                        ),
                    ),
                ),


                'post'         => array(
                    'type'        => 'post', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Selected post', EM_SHORTCODES_TEXTDOMAIN),
                    'post_type'   => 'service',
                    'description' => __('Selected post', EM_SHORTCODES_TEXTDOMAIN),
                    'multiple'    => TRUE,
                ),

                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Show box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                ),

                'grid_class'   => array(
                    'type'        => 'text', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Grid Class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Put Bootstrap grid class', EM_SHORTCODES_TEXTDOMAIN),
                    'default'     => 'col-md-3',
                ),
            )
        );

        $shortcode->register('services', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_services_shortcode');


    function hippo_shortcode_services($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'style'      => 'style1',
            'post'       => '0',
            'shadow_class'     => '',
            'grid_class' => 'col-md-3',
        ), $atts);

        // limit=column*row | col-md-* = 12/column
        // $posts_per_page = $attributes[ 'column' ] * $attributes[ 'row' ];
        // $grid_class     = (12 / $attributes[ 'column' ]);
        $ps = explode(',', $attributes[ 'post' ]);

        ob_start();
        ?>



        <?php if ($attributes[ 'style' ] == 'style1') { ?>

        <div class="showcase-right">
        <ul class="top-service-box <?php echo $attributes[ 'shadow_class' ] ?>">

    <?php } elseif ($attributes[ 'style' ] == 'style2') { ?>

        <div class="row service-content clearfix <?php echo $attributes[ 'shadow_class' ] ?>">

    <?php } ?>



        <?php
        // WP_Query arguments
        $args = array(
            'post__in'    => $ps,
            'posts_per_page' => -1,
            'post_type'   => 'service',
            'post_status' => 'publish',
            'orderby'     => 'menu_order',
            'order'       => 'ASC'
        );


        // The Query
        $query = new WP_Query($args);
        // The Loop
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $post     = get_post();
                $contents = get_extended($post->post_content);

                ?>


                <?php if ($attributes[ 'style' ] == 'style1') { ?>


                    <li>
                        <h2><?php the_title(); ?></h2>

                        <p><?php echo wpautop($contents[ 'main' ]); ?></p>
                        <a href="<?php the_permalink(); ?>"><?php _e('DETAILS', EM_SHORTCODES_TEXTDOMAIN) ?></a>
                    </li>


                <?php } elseif ($attributes[ 'style' ] == 'style2') { ?>

                    <div class="<?php echo $attributes[ 'grid_class' ] ?> col-sm-6 col-xs-12">
                        <div class="single-services">
                            <?php if (has_post_thumbnail()) { ?>

                                <?php the_post_thumbnail('service-thumb2', array('class' => 'img-responsive')); ?>

                            <?php } ?>


                            <h4><?php the_title(); ?></h4>

                            <p><?php echo hippo_before_more_content($post->post_content); ?></p>

                            <div class="readmore"><a
                                    href="<?php the_permalink(); ?>"><?php _e('More', EM_SHORTCODES_TEXTDOMAIN) ?></a>
                            </div>
                        </div>
                    </div>

                <?php
                }
            }

        } else {
            echo '<div class="col-md-12">' . __('No service item found.', EM_SHORTCODES_TEXTDOMAIN) . '</div>';
        }
        ?>

        <?php if ($attributes[ 'style' ] == 'style2'){ ?>

        </div>
    <?php } ?>


        <?php if ($attributes[ 'style' ] == 'style1') { ?>
        </ul>
        </div>
    <?php } ?>

        <?php

        return ob_get_clean();
    }

    add_shortcode('services', 'hippo_shortcode_services');