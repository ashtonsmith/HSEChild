<?php



    function hippo_register_tab_shortcode($shortcode)
    {

        global $fontawesome_icons;


        $register_tabs = array(
            'title'       => __('Tabs', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Show Tab', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(
                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Add box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                ),
            )
        );


        $shortcode->register('tabs', $register_tabs);

        $register_tab = array(
            'title'           => __('Tab', EM_SHORTCODES_TEXTDOMAIN),
            'description'     => __('Tab', EM_SHORTCODES_TEXTDOMAIN),
            'child_of'        => array('tabs'), // use if its a child
            'cloneable'       => TRUE, // use if its a child
            'editor_contents' => TRUE,
            'attributes'      => array(

                'icon'  => array(
                    'type'        => 'icon',
                    'label'       => __('Tab icon', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Tab icon', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => $fontawesome_icons
                ),

                'title' => array(
                    'type'        => 'text',
                    'label'       => __('Tab title', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Tab title', EM_SHORTCODES_TEXTDOMAIN)
                ),
            )
        );

        $shortcode->register('tab', $register_tab);

    }

    add_action('hippo_register_shortcode', 'hippo_register_tab_shortcode');


    $hippo_shortcode_tabs = array();

    function hippo_shortcode_tabs($atts, $contents = '')
    {


        $attributes = shortcode_atts(array(
            'shadow_class'=>''
        ), $atts);

        global $hippo_shortcode_tabs;

        do_shortcode($contents);


        ob_start();
        ?>
        <div class="tab-box <?php echo $attributes['shadow_class'] ?>">
            <div class="tab-area">

                <div id="tabs" class="home-tab">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs responsive">

                        <?php foreach ($hippo_shortcode_tabs as $i => $tab) { ?>

                            <li class="<?php echo ($i == 0) ? 'active' : '' ?>"><a href="#tabs-<?php echo $i ?>"
                                                                                   data-toggle="tab">
                                    <i class="<?php echo $tab[ 'icon' ] ?>"></i>&nbsp; <?php echo $tab[ 'title' ] ?>
                                </a>
                            </li>

                        <?php } ?>
                    </ul>


                    <!-- Tab panes -->
                    <div class="tab_container">
                        <div class="tab-content">
                            <?php foreach ($hippo_shortcode_tabs as $j => $tabcontent) { ?>

                                <div class="tab-pane <?php echo ($j == 0) ? 'active' : '' ?> fade in"
                                     id="tabs-<?php echo $j ?>">
                                    <?php echo do_shortcode($tabcontent[ 'content' ]); ?>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php
        return ob_get_clean();
    }

    add_shortcode('tabs', 'hippo_shortcode_tabs');

    function hippo_shortcode_tab($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'icon'    => '',
            'title'   => '',
            'content' => $contents,
        ), $atts);

        global $hippo_shortcode_tabs;

        $hippo_shortcode_tabs[ ] = $attributes;

    }

    add_shortcode('tab', 'hippo_shortcode_tab');