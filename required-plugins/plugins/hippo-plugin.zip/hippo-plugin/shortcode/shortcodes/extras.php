<?php

    /**
     * Alert
     *
     * @param $shortcode
     */

    function hippo_register_alert_shortcode($shortcode)
    {
        $register = array(
            'title'           => __('Alert style text', EM_SHORTCODES_TEXTDOMAIN),
            'description'     => __('Alert style text', EM_SHORTCODES_TEXTDOMAIN),
            'editor_contents' => TRUE,
            'attributes'  => array(
                'title'  => array(
                    'type'        => 'text',
                    'label'       => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Title', EM_SHORTCODES_TEXTDOMAIN),
                ),
            )

        );

        $shortcode->register('alert', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_alert_shortcode');


    function hippo_shortcode_alert($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'title' => '',
        ), $atts);

        ob_start();
        ?>
        <div class="alert-wrapper">
            <h3><?php echo $attributes ['title'] ?></h3>
        
            <div class="alert alert-warning"> 
                <p><?php echo do_shortcode($contents); ?></p>
            </div>
        </div>

        <?php
        return ob_get_clean();
    }

    add_shortcode('alert', 'hippo_shortcode_alert');



    /**
     * Contact Info Wrapper
     *
     * @param $shortcode
     */

    function hippo_register_contact_info_wrapper_shortcode($shortcode)
    {
        $register = array(
            'title'           => __('Contact info wrapper', EM_SHORTCODES_TEXTDOMAIN),
            'description'     => __('Contact info wrapper', EM_SHORTCODES_TEXTDOMAIN),
            'editor_contents' => TRUE,
        );

        $shortcode->register('contact-info-wrapper', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_contact_info_wrapper_shortcode');


    function hippo_shortcode_contact_info_wrapper($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(), $atts);
        ob_start();
        ?>
        <div class="contact-info"><?php echo do_shortcode($contents); ?></div>
        <?php
        return ob_get_clean();
    }

    add_shortcode('contact-info-wrapper', 'contact_info_wrapper');


    /**
     * Icon
     *
     * @param $shortcode
     */


    function hippo_register_icon_shortcode($shortcode)
    {

        global $fontawesome_icons;
        $register = array(
            'title'       => __('Icon', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('FontAwesome Icon', EM_SHORTCODES_TEXTDOMAIN),

            'attributes'  => array(

                'icon'  => array(
                    'type'        => 'icon',
                    'label'       => __('Social Icons', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Choose desire share icon', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => $fontawesome_icons
                ),

                'size'  => array(
                    'type'        => 'select', // text, textarea, color, select, select2, image, font, editor_contents
                    'label'       => __('Icon size', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Icon size', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''      => 'Normal',
                        'fa-lg' => 'Large',
                        'fa-2x' => '2X Large',
                        'fa-3x' => '3X Large',
                        'fa-4x' => '4X Large',
                        'fa-5x' => '5X Large',
                    )
                ),
                'class' => array(
                    'type'        => 'text',
                    'label'       => __('Class', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Extra class for icon', EM_SHORTCODES_TEXTDOMAIN)
                ),
            )

        );

        $shortcode->register('icon', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_icon_shortcode');


    function hippo_shortcode_icon($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(

            'class' => '',
            'icon'  => '',
            'size'  => ''
        ), $atts);
        ob_start();
        ?>
        <i class="<?php echo $attributes[ 'icon' ] ?> <?php echo $attributes[ 'size' ] ?> <?php echo $attributes[ 'class' ] ?>"></i>
        <?php
        return ob_get_clean();
    }

    add_shortcode('icon', 'hippo_shortcode_icon');

    function hippo_widget_title_icon($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(), $atts);
        ob_start();
        ?>
        <span class="<?php echo $contents ?>"></span>
        <?php
        return ob_get_clean();
    }

    add_shortcode('widget-icon', 'hippo_widget_title_icon');


    /**
     * Map
     *
     * @param $shortcode
     */

    function hippo_register_map_shortcode($shortcode)
    {

        $register = array(
            'title'       => __('Google Map', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Embed Google Map', EM_SHORTCODES_TEXTDOMAIN),
            'attributes'  => array(

                'lat'     => array(
                    'type'        => 'text',
                    'label'       => 'Latitude',
                    'description' => 'Map Latitude',
                ),

                'lng'     => array(
                    'type'        => 'text',
                    'label'       => 'Longitude',
                    'description' => 'Map Longitude',
                ),

                'content' => array(
                    'type'        => 'text',
                    'label'       => 'Popup Text',
                    'description' => 'Map Popup Text',
                ),

                'shadow_class' => array(
                    'type'        => 'select',
                    'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Show box shadow', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => array(
                        ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                        'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                    ),
                ),

            )
        );

        $shortcode->register('map', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_map_shortcode');


    function hippo_shortcode_map($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'lat'     => '',
            'lng'     => '',
            'content' => '',
            'shadow_class' => '',
        ), $atts);

        ob_start();
        ?>
        <div class="contact-map <?php echo $attributes[ 'shadow_class' ] ?>">
            <div class="map">
                <div id="map-canvas" data-map-lat="<?php echo $attributes['lat'] ?>"
                     data-map-lng="<?php echo $attributes['lng'] ?>"
                     data-map-content="<?php echo $attributes['content'] ?>">
                 </div>
             </div>
         </div>

        <?php
        return ob_get_clean();
    }

    add_shortcode('map', 'hippo_shortcode_map');

//end map

    function hippo_register_hippo_oembed($shortcode)
    {

        $register = array(
            'title'       => __('oEmbed', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Embed WP supported links.', EM_SHORTCODES_TEXTDOMAIN),

            'attributes'  => array(

                'link' => array(
                    'type'        => 'text',
                    'label'       => __('oEmbed Link', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('WP supported oEmbed link to dipslay.', EM_SHORTCODES_TEXTDOMAIN)
                ),

            )

        );

        $shortcode->register('hippo-oembed', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_hippo_oembed');

    function hippo_shortcode_hippo_oembed($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'link' => ''
        ), $atts);
        ob_start();
        echo '<div class="hippo-oembed">';
        echo wp_oembed_get($attributes[ 'link' ]);
        echo '</div>';

        return ob_get_clean();
    }

    add_shortcode('hippo-oembed', 'hippo_shortcode_hippo_oembed');



// Promo banner
    function hippo_register_hippo_banner($shortcode)
    {

        global $fontawesome_icons;

        $register = array(
            'title'       => __('Banner', EM_SHORTCODES_TEXTDOMAIN),
            'description' => __('Banner', EM_SHORTCODES_TEXTDOMAIN),
            'editor_contents' => TRUE,
            'attributes'  => array(

            'icon' => array(
                    'type'        => 'icon',
                    'label'       => __('Banner icon', EM_SHORTCODES_TEXTDOMAIN),
                    'description' => __('Select icon', EM_SHORTCODES_TEXTDOMAIN),
                    'options'     => $fontawesome_icons
                ),

             'title' => array(
                'type'        => 'text',
                'label'       => __('Banner title', EM_SHORTCODES_TEXTDOMAIN),
                'description' => __('Banner title', EM_SHORTCODES_TEXTDOMAIN)
                ),

             'shadow_class' => array(
                 'type'        => 'select',
                 'label'       => __('Box Shodow', EM_SHORTCODES_TEXTDOMAIN),
                 'description' => __('Add box shadow', EM_SHORTCODES_TEXTDOMAIN),
                 'options'     => array(
                     ''           => __('No', EM_SHORTCODES_TEXTDOMAIN),
                     'box-shadow' => __('Yes', EM_SHORTCODES_TEXTDOMAIN),
                 ),
             )

            )

        );

        $shortcode->register('banner', $register);
    }

    add_action('hippo_register_shortcode', 'hippo_register_hippo_banner');

    function hippo_shortcode_hippo_banner($atts, $contents = '')
    {
        $attributes = shortcode_atts(array(
            'icon' => '',
            'title' => '',
            'shadow_class' => '',
        ), $atts);
        ob_start();

        ?>

        <div class="banner-box <?php echo $attributes ['shadow_class'] ?>">
            <div class="slid-bottom-promo">
                <div class="icon"><span class="<?php echo $attributes ['icon'] ?>"></span></div>
                <h2><?php echo $attributes ['title'] ?></h2>
                <?php echo do_shortcode($contents); ?>
            </div>
        </div>

        
    <?php
        return ob_get_clean();
    }

    add_shortcode('banner', 'hippo_shortcode_hippo_banner');
