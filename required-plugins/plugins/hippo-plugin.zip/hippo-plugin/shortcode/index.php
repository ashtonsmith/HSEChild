<?php


    !defined(ABSPATH) or die('Keep silent!');

    define('EM_SHORTCODES_TEXTDOMAIN', HIPPO_PLUGIIN_TEXTDOMAIN);
    define('EM_SHORTCODES_DIR', dirname(__FILE__));
    define('EM_SHORTCODES_RELATIVE_PATH', dirname(plugin_basename(__FILE__)));
    define('EM_SHORTCODES_URL', plugins_url(basename(dirname(__FILE__)), dirname(__FILE__)));
    define('EM_SHORTCODES_PREFIX', 'em_Shortcode_');


    define('EM_SHORTCODE_BUTTON_TITLE', __('Insert Shortcode', EM_SHORTCODES_TEXTDOMAIN));
    define('EM_SHORTCODE_POPUP_TITLE', __('Shortcodes', EM_SHORTCODES_TEXTDOMAIN));
    define('EM_SHORTCODE_POPUP_WIDTH', 655);
    define('EM_SHORTCODE_POPUP_HEIGHT', 400);

    define('EM_THEME_STYLESHEET_DIR', get_stylesheet_directory());
    define('EM_THEME_TEMPLATE_DIR', get_template_directory());


    define('EM_SHORTCODE_FILES_DIR', 'shortcodes');


    require_once EM_SHORTCODES_DIR . '/includes/class-emshortcode-engine.php';
    require_once EM_SHORTCODES_DIR . '/includes/class-emshortcode-attr.php';

    add_action('init', function(){

        do_action('hippo_register_shortcode', em_Shortcodes_Engine::getInstance());

    });


    //$shortcode = em_Shortcodes_Engine::getInstance();

    /**
     * Shortcode file importing, this function will search on child theme directory
     * then template directory then plugin directory :)
     *
     * @param $file_name
     */
    function hippo_import_shortcode($file_name)
    {

        $on_stylesheet_dir      = EM_THEME_STYLESHEET_DIR . '/' . EM_SHORTCODE_FILES_DIR;
        $file_on_stylesheet_dir = EM_THEME_STYLESHEET_DIR . '/' . EM_SHORTCODE_FILES_DIR . '/' . $file_name . '.php';

        $on_template_dir      = EM_THEME_TEMPLATE_DIR . '/' . EM_SHORTCODE_FILES_DIR;
        $file_on_template_dir = EM_THEME_TEMPLATE_DIR . '/' . EM_SHORTCODE_FILES_DIR . '/' . $file_name . '.php';

        $file_on_plugin_dir = EM_SHORTCODES_DIR . '/' . EM_SHORTCODE_FILES_DIR . '/' . $file_name . '.php';


        if (file_exists($on_stylesheet_dir) and file_exists($file_on_stylesheet_dir)) {
            include_once $file_on_stylesheet_dir;
        } elseif (file_exists($on_template_dir) and file_exists($file_on_template_dir)) {
            include_once $file_on_template_dir;
        } else {
            include_once $file_on_plugin_dir;
        }
    }

    /**
     * Get previous content of <!--more--> tag
     *
     * @param $contents
     *
     * @return mixed|void
     */
    function hippo_before_more_content($contents)
    {
        $contents = get_extended($contents);
        return apply_filters('the_content', wpautop(do_shortcode($contents[ 'main' ])));
    }

    /**
     * Check that content has <!--more--> tag or not :)
     *
     * @param $contents
     *
     * @return bool
     */

    function hippo_has_more_content($contents)
    {
        $contents = get_extended($contents);
        return !empty($contents[ 'extended' ]);
    }

    //
    require_once EM_SHORTCODES_DIR . '/import-shortcode.php';


    //----------------------------------------------------------------------
    // Removing p tag which wrapping shortcodes
    //----------------------------------------------------------------------

    function hippo_shortcode_empty_paragraph_fix($content)
    {
        $array = array(
            '<p>['    => '[',
            ']</p>'   => ']',
            ']<br />' => ']'
        );

        return strtr($content, $array);
    }

    add_filter('the_content', 'hippo_shortcode_empty_paragraph_fix');
    add_filter('widget_text', 'hippo_shortcode_empty_paragraph_fix');
    add_filter('widget_text', 'do_shortcode');
    add_filter('widget_title', 'do_shortcode');

