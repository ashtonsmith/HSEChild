<?php


    function hippo_post_type_services()
    {

        $labels = array(
            'name'               => _x('Services', HIPPO_PLUGIIN_TEXTDOMAIN),
            'singular_name'      => _x('Service', HIPPO_PLUGIIN_TEXTDOMAIN),
            'menu_name'          => __('Service', HIPPO_PLUGIIN_TEXTDOMAIN),
            'parent_item_colon'  => __('Parent Service:', HIPPO_PLUGIIN_TEXTDOMAIN),
            'all_items'          => __('Services', HIPPO_PLUGIIN_TEXTDOMAIN),
            'view_item'          => __('View Service', HIPPO_PLUGIIN_TEXTDOMAIN),
            'add_new_item'       => __('Add New Service', HIPPO_PLUGIIN_TEXTDOMAIN),
            'add_new'            => __('New Service', HIPPO_PLUGIIN_TEXTDOMAIN),
            'edit_item'          => __('Edit Service', HIPPO_PLUGIIN_TEXTDOMAIN),
            'update_item'        => __('Update Service', HIPPO_PLUGIIN_TEXTDOMAIN),
            'search_items'       => __('Search Service', HIPPO_PLUGIIN_TEXTDOMAIN),
            'not_found'          => __('No Service Item found', HIPPO_PLUGIIN_TEXTDOMAIN),
            'not_found_in_trash' => __('No Service Item found in Trash', HIPPO_PLUGIIN_TEXTDOMAIN),
        );
        $args   = array(
            'description'         => __('Service', HIPPO_PLUGIIN_TEXTDOMAIN),
            'labels'              => $labels,
            'supports'            => array('title', 'editor', 'page-attributes', 'thumbnail'),
            'taxonomies'          => array(),
            'hierarchical'        => FALSE,
            'public'              => TRUE,
            'show_ui'             => TRUE,
            'show_in_menu'        => TRUE,
            'show_in_nav_menus'   => FALSE,
            'show_in_admin_bar'   => TRUE,
            'menu_position'       => 6,
            'menu_icon'           => 'dashicons-screenoptions',
            'can_export'          => TRUE,
            'has_archive'         => FALSE,
            'exclude_from_search' => TRUE,
            'publicly_queryable'  => TRUE,
            'capability_type'     => 'post',
        );


        register_post_type('service', $args);


    }

    // Hook into the 'init' action
    add_action('init', 'hippo_post_type_services');