<?php


$prefix = 'post_';

$fields = array(

    array(
            'label' => 'Featured Video (.webm)', // <label>
            'desc'  => 'Webm Video like: example.webm', // description
            'id'    => $prefix . 'featured_webm', // field id and name
            'type'  => 'media', // type of field
            ),

    array(
            'label' => 'Featured Video (.ogv)', // <label>
            'desc'  => 'Webm Video like: example.ogv', // description
            'id'    => $prefix . 'featured_ogv', // field id and name
            'type'  => 'media', // type of field
            ),

    array(
            'label'   => 'Featured Video (.mp4)', // <label>
            'desc'    => 'Webm Video like: example.mp4', // description
            'id'      => $prefix . 'featured_mp4', // field id and name
            'type'    => 'media', // type of field
            'divider' => TRUE
            ),

    array(
            'label'   => 'Embed Video', // <label>
            'desc'    => 'Embed video. Supported list: http://codex.wordpress.org/Embeds', // description
            'id'      => $prefix . 'video_embed', // field id and name
            'type'    => 'url', // type of field
            'divider' => TRUE
            ),





    );

    /**
     * Instantiate the class with all variables to create a meta box
     * var $id string meta box id
     * var $title string title
     * var $fields array fields
     * var $page string|array post type to add meta box to
     * var $js bool including javascript or not
     */
    new custom_add_meta_box('post_video_meta', 'Video Options', $fields, 'post', TRUE);


    $fields = array(

        array(
            'label'   => 'Featured Audio (.mp3)', // <label>
            'desc'    => 'MP3 Audio like: example.mp3', // description
            'id'      => $prefix . 'featured_mp3', // field id and name
            'type'    => 'media', // type of field
            'divider' => TRUE
            ),
        array(
            'label' => 'Featured Audio (.ogg)', // <label>
            'desc'  => 'OGG Audio like: example.ogg', // description
            'id'    => $prefix . 'featured_ogg', // field id and name
            'type'  => 'media', // type of field
            ),

        array(
            'label' => 'Embed Audio', // <label>
            'desc'  => 'Embed audio. Supported list: http://codex.wordpress.org/Embeds', // description
            'id'    => $prefix . 'audio_embed', // field id and name
            'type'  => 'url', // type of field
            'divider'=>true
            ),
        );

    /**
     * Instantiate the class with all variables to create a meta box
     * var $id string meta box id
     * var $title string title
     * var $fields array fields
     * var $page string|array post type to add meta box to
     * var $js bool including javascript or not
     */
    new custom_add_meta_box('post_audio_meta', 'Audio Options', $fields, 'post', TRUE);


    

    $fields = array(


        array(
            'label' => 'Featured Gallery', // <label>
            'desc'  => 'Featured Gallery', // description
            'id'    => $prefix . 'featured_gallery', // field id and name
            'type'  => 'gallery', // type of field
            )
        );
    

    /**
     * Instantiate the class with all variables to create a meta box
     * var $id string meta box id
     * var $title string title
     * var $fields array fields
     * var $page string|array post type to add meta box to
     * var $js bool including javascript or not
     */
  // new custom_add_meta_box('post_gallery_meta', 'Featured Gallery', $fields, 'post', TRUE);



