<?php


    $prefix = 'page_';

    $fields = array(


        array(
            'label' => 'Header Image', // <label>
            'desc'  => 'Header background image. dimension: 1400px &times; 500px', // description
            'id'    => $prefix . 'header_image', // field id and name
            'type'  => 'image', // type of field
        )
    );

    /**
     * Instantiate the class with all variables to create a meta box
     * var $id string meta box id
     * var $title string title
     * var $fields array fields
     * var $page string|array post type to add meta box to
     * var $js bool including javascript or not
     */
    new custom_add_meta_box('page_options', 'Page Options', $fields, 'page', TRUE);


