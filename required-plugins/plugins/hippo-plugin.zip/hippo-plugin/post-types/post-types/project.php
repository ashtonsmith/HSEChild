<?php


    function hippo_post_type_project()
    {

        $labels = array(
            'name'               => _x('Project', HIPPO_PLUGIIN_TEXTDOMAIN),
            'singular_name'      => _x('Project', HIPPO_PLUGIIN_TEXTDOMAIN),
            'menu_name'          => __('Project', HIPPO_PLUGIIN_TEXTDOMAIN),
            'parent_item_colon'  => __('Parent Project:', HIPPO_PLUGIIN_TEXTDOMAIN),
            'all_items'          => __('Projects', HIPPO_PLUGIIN_TEXTDOMAIN),
            'view_item'          => __('View Project', HIPPO_PLUGIIN_TEXTDOMAIN),
            'add_new_item'       => __('Add New Project', HIPPO_PLUGIIN_TEXTDOMAIN),
            'add_new'            => __('New Project', HIPPO_PLUGIIN_TEXTDOMAIN),
            'edit_item'          => __('Edit Project', HIPPO_PLUGIIN_TEXTDOMAIN),
            'update_item'        => __('Update Project', HIPPO_PLUGIIN_TEXTDOMAIN),
            'search_items'       => __('Search Project', HIPPO_PLUGIIN_TEXTDOMAIN),
            'not_found'          => __('No Project Item found', HIPPO_PLUGIIN_TEXTDOMAIN),
            'not_found_in_trash' => __('No Project Item found in Trash', HIPPO_PLUGIIN_TEXTDOMAIN),
        );
        $args   = array(
            'description'         => __('Project', HIPPO_PLUGIIN_TEXTDOMAIN),
            'labels'              => $labels,
            'supports'            => array('title', 'editor', 'page-attributes','thumbnail'),
            'taxonomies'          => array('project-type'),
            'hierarchical'        => FALSE,
            'public'              => TRUE,
            'show_ui'             => TRUE,
            'show_in_menu'        => TRUE,
            'show_in_nav_menus'   => FALSE,
            'show_in_admin_bar'   => TRUE,
            'menu_position'       => 7,
            'menu_icon'           => 'dashicons-forms',
            'can_export'          => TRUE,
            'has_archive'         => FALSE,
            'exclude_from_search' => TRUE,
            'publicly_queryable'  => TRUE,
            'capability_type'     => 'post',
        );


        register_post_type('project', $args);


    }

    // Hook into the 'init' action
    add_action('init', 'hippo_post_type_project');




    function register_taxonomy_project_type() {

        $labels = array(
            'name' => _x( 'Types', 'type' ),
            'singular_name' => _x( 'Type', 'type' ),
            'search_items' => _x( 'Search Types', 'type' ),
            'popular_items' => _x( 'Popular Types', 'type' ),
            'all_items' => _x( 'All Types', 'type' ),
            'parent_item' => _x( 'Parent Type', 'type' ),
            'parent_item_colon' => _x( 'Parent Type:', 'type' ),
            'edit_item' => _x( 'Edit Type', 'type' ),
            'update_item' => _x( 'Update Type', 'type' ),
            'add_new_item' => _x( 'Add New Type', 'type' ),
            'new_item_name' => _x( 'New Type', 'type' ),
            'separate_items_with_commas' => _x( 'Separate types with commas', 'type' ),
            'add_or_remove_items' => _x( 'Add or remove Types', 'type' ),
            'choose_from_most_used' => _x( 'Choose from most used Types', 'type' ),
            'menu_name' => _x( 'Types', 'type' ),
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'show_in_nav_menus' => false,
            'show_ui' => true,
            'show_tagcloud' => false,
            'show_admin_column' => true,
            'hierarchical' => true,

            'rewrite' => true,
            'query_var' => true
        );

        register_taxonomy( 'project-type', array('project'), $args );
    }

    add_action( 'init', 'register_taxonomy_project_type' );