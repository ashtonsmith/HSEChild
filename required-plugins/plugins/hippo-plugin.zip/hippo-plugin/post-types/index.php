<?php



    include_once HIPPO_PLUGIN_DIR . '/post-types/post-types/services.php';
    include_once HIPPO_PLUGIN_DIR . '/post-types/post-types/project.php';
    include_once HIPPO_PLUGIN_DIR . '/post-types/post-types/page-meta.php';
    include_once HIPPO_PLUGIN_DIR . '/post-types/post-types/post-meta.php';



